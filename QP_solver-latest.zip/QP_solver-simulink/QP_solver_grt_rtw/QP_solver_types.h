/*
 * QP_solver_types.h
 *
 * Code generation for model "QP_solver".
 *
 * Model version              : 1.690
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Wed May 19 00:22:07 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Execution efficiency
 * Validation result: Not run
 */

#ifndef RTW_HEADER_QP_solver_types_h_
#define RTW_HEADER_QP_solver_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"

/* Model Code Variants */

/* Custom Type definition for MATLAB Function: '<Root>/MATLAB Function' */
#ifndef struct_tag_sMBHLn8PGyUK14vNDw4vTyG
#define struct_tag_sMBHLn8PGyUK14vNDw4vTyG

struct tag_sMBHLn8PGyUK14vNDw4vTyG
{
  real_T xstar[5];
  real_T fstar;
  real_T firstorderopt;
  real_T lambda[9];
  int32_T state;
  real_T maxConstr;
  int32_T iterations;
  real_T searchDir[5];
};

#endif                                 /*struct_tag_sMBHLn8PGyUK14vNDw4vTyG*/

#ifndef typedef_sMBHLn8PGyUK14vNDw4vTyG_QP_so_T
#define typedef_sMBHLn8PGyUK14vNDw4vTyG_QP_so_T

typedef struct tag_sMBHLn8PGyUK14vNDw4vTyG sMBHLn8PGyUK14vNDw4vTyG_QP_so_T;

#endif                               /*typedef_sMBHLn8PGyUK14vNDw4vTyG_QP_so_T*/

#ifndef struct_tag_sL9bDKomAYkxZSVrG9w6En
#define struct_tag_sL9bDKomAYkxZSVrG9w6En

struct tag_sL9bDKomAYkxZSVrG9w6En
{
  int32_T MaxIterations;
  real_T ConstrRelTolFactor;
  real_T ProbRelTolFactor;
  boolean_T RemainFeasible;
};

#endif                                 /*struct_tag_sL9bDKomAYkxZSVrG9w6En*/

#ifndef typedef_sL9bDKomAYkxZSVrG9w6En_QP_sol_T
#define typedef_sL9bDKomAYkxZSVrG9w6En_QP_sol_T

typedef struct tag_sL9bDKomAYkxZSVrG9w6En sL9bDKomAYkxZSVrG9w6En_QP_sol_T;

#endif                               /*typedef_sL9bDKomAYkxZSVrG9w6En_QP_sol_T*/

#ifndef struct_tag_sPZu81U7pb4xx4nEpbF8lJH
#define struct_tag_sPZu81U7pb4xx4nEpbF8lJH

struct tag_sPZu81U7pb4xx4nEpbF8lJH
{
  real_T grad[5];
  real_T Hx[4];
  boolean_T hasLinear;
  int32_T nvar;
  int32_T maxVar;
  real_T beta;
  real_T rho;
  int32_T objtype;
  int32_T prev_objtype;
  int32_T prev_nvar;
  boolean_T prev_hasLinear;
  real_T gammaScalar;
};

#endif                                 /*struct_tag_sPZu81U7pb4xx4nEpbF8lJH*/

#ifndef typedef_sPZu81U7pb4xx4nEpbF8lJH_QP_so_T
#define typedef_sPZu81U7pb4xx4nEpbF8lJH_QP_so_T

typedef struct tag_sPZu81U7pb4xx4nEpbF8lJH sPZu81U7pb4xx4nEpbF8lJH_QP_so_T;

#endif                               /*typedef_sPZu81U7pb4xx4nEpbF8lJH_QP_so_T*/

#ifndef struct_tag_s44Ocoq5jREA8hvE3ik8GDG
#define struct_tag_s44Ocoq5jREA8hvE3ik8GDG

struct tag_s44Ocoq5jREA8hvE3ik8GDG
{
  real_T workspace_double[45];
  int32_T workspace_int[9];
  int32_T workspace_sort[9];
};

#endif                                 /*struct_tag_s44Ocoq5jREA8hvE3ik8GDG*/

#ifndef typedef_s44Ocoq5jREA8hvE3ik8GDG_QP_so_T
#define typedef_s44Ocoq5jREA8hvE3ik8GDG_QP_so_T

typedef struct tag_s44Ocoq5jREA8hvE3ik8GDG s44Ocoq5jREA8hvE3ik8GDG_QP_so_T;

#endif                               /*typedef_s44Ocoq5jREA8hvE3ik8GDG_QP_so_T*/

#ifndef struct_tag_sH6iCrytcpDRkZmGBtfsOaB
#define struct_tag_sH6iCrytcpDRkZmGBtfsOaB

struct tag_sH6iCrytcpDRkZmGBtfsOaB
{
  int32_T mConstr;
  int32_T mConstrOrig;
  int32_T mConstrMax;
  int32_T nVar;
  int32_T nVarOrig;
  int32_T nVarMax;
  int32_T ldA;
  real_T lb[5];
  real_T ub[5];
  int32_T indexLB[5];
  int32_T indexUB[5];
  int32_T indexFixed[5];
  int32_T mEqRemoved;
  real_T ATwset[45];
  real_T bwset[9];
  int32_T nActiveConstr;
  real_T maxConstrWorkspace[9];
  int32_T sizes[5];
  int32_T sizesNormal[5];
  int32_T sizesPhaseOne[5];
  int32_T sizesRegularized[5];
  int32_T sizesRegPhaseOne[5];
  int32_T isActiveIdx[6];
  int32_T isActiveIdxNormal[6];
  int32_T isActiveIdxPhaseOne[6];
  int32_T isActiveIdxRegularized[6];
  int32_T isActiveIdxRegPhaseOne[6];
  boolean_T isActiveConstr[9];
  int32_T Wid[9];
  int32_T Wlocalidx[9];
  int32_T nWConstr[5];
  int32_T probType;
  real_T SLACK0;
};

#endif                                 /*struct_tag_sH6iCrytcpDRkZmGBtfsOaB*/

#ifndef typedef_sH6iCrytcpDRkZmGBtfsOaB_QP_so_T
#define typedef_sH6iCrytcpDRkZmGBtfsOaB_QP_so_T

typedef struct tag_sH6iCrytcpDRkZmGBtfsOaB sH6iCrytcpDRkZmGBtfsOaB_QP_so_T;

#endif                               /*typedef_sH6iCrytcpDRkZmGBtfsOaB_QP_so_T*/

#ifndef struct_tag_s5b283nY1IMTh9oT8JoHmsB
#define struct_tag_s5b283nY1IMTh9oT8JoHmsB

struct tag_s5b283nY1IMTh9oT8JoHmsB
{
  int32_T ldq;
  real_T QR[81];
  real_T Q[81];
  int32_T jpvt[9];
  int32_T mrows;
  int32_T ncols;
  real_T tau[9];
  int32_T minRowCol;
  boolean_T usedPivoting;
};

#endif                                 /*struct_tag_s5b283nY1IMTh9oT8JoHmsB*/

#ifndef typedef_s5b283nY1IMTh9oT8JoHmsB_QP_so_T
#define typedef_s5b283nY1IMTh9oT8JoHmsB_QP_so_T

typedef struct tag_s5b283nY1IMTh9oT8JoHmsB s5b283nY1IMTh9oT8JoHmsB_QP_so_T;

#endif                               /*typedef_s5b283nY1IMTh9oT8JoHmsB_QP_so_T*/

#ifndef struct_tag_sXPHwJUUvhPPvi7FGUnZtdG
#define struct_tag_sXPHwJUUvhPPvi7FGUnZtdG

struct tag_sXPHwJUUvhPPvi7FGUnZtdG
{
  real_T FMat[81];
  int32_T ldm;
  int32_T ndims;
  int32_T info;
  real_T scaleFactor;
  boolean_T ConvexCheck;
  real_T regTol_;
  real_T workspace_[432];
  real_T workspace2_[432];
};

#endif                                 /*struct_tag_sXPHwJUUvhPPvi7FGUnZtdG*/

#ifndef typedef_sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T
#define typedef_sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T

typedef struct tag_sXPHwJUUvhPPvi7FGUnZtdG sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T;

#endif                               /*typedef_sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T*/

#ifndef struct_tag_s4lHOiXA0GHbse0IgoBY6ZF
#define struct_tag_s4lHOiXA0GHbse0IgoBY6ZF

struct tag_s4lHOiXA0GHbse0IgoBY6ZF
{
  real_T InitDamping;
  char_T FiniteDifferenceType[7];
  boolean_T SpecifyObjectiveGradient;
  boolean_T ScaleProblem;
  boolean_T SpecifyConstraintGradient;
  boolean_T NonFiniteSupport;
  boolean_T IterDisplaySQP;
  real_T FiniteDifferenceStepSize;
  real_T MaxFunctionEvaluations;
  boolean_T IterDisplayQP;
  real_T PricingTolerance;
  char_T Algorithm[10];
  real_T ObjectiveLimit;
  real_T ConstraintTolerance;
  real_T OptimalityTolerance;
  real_T StepTolerance;
  real_T MaxIterations;
  real_T FunctionTolerance;
  char_T SolverName[8];
  boolean_T CheckGradients;
  char_T Diagnostics[3];
  real_T DiffMaxChange;
  real_T DiffMinChange;
  char_T Display[5];
  char_T FunValCheck[3];
  boolean_T UseParallel;
  char_T LinearSolver[4];
  char_T SubproblemAlgorithm[2];
};

#endif                                 /*struct_tag_s4lHOiXA0GHbse0IgoBY6ZF*/

#ifndef typedef_s4lHOiXA0GHbse0IgoBY6ZF_QP_so_T
#define typedef_s4lHOiXA0GHbse0IgoBY6ZF_QP_so_T

typedef struct tag_s4lHOiXA0GHbse0IgoBY6ZF s4lHOiXA0GHbse0IgoBY6ZF_QP_so_T;

#endif                               /*typedef_s4lHOiXA0GHbse0IgoBY6ZF_QP_so_T*/

/* Forward declaration for rtModel */
typedef struct tag_RTM_QP_solver_T RT_MODEL_QP_solver_T;

#endif                                 /* RTW_HEADER_QP_solver_types_h_ */
