#include "QP_solver.h"
#include <unistd.h>
int main()
{
    float dt = 1.0f / 400.0f;
    QP_solver_initialize();
    float timer = 0.0f;
    float final_time = 25.0f;

    QP_solver_U.Wx = 1.0f;
    QP_solver_U.Wy = 1.0f;
    QP_solver_U.Wz = 1.0f;
    QP_solver_U.Wt = 1.0f;
    QP_solver_U.lb = 0.0f;
    QP_solver_U.ub = 100.0f;

    while (timer <= final_time)
    {
        usleep(2500);
        QP_solver_U.Mx = 50.0f;
        QP_solver_U.My = 0.0f;
        QP_solver_U.Mz = 0.0f;
        QP_solver_U.T = 50.0f;

        QP_solver_step();
        timer += dt;

        printf("X = [%.4f %.4f %.4f %.4f]\n", QP_solver_Y.X[0], QP_solver_Y.X[1], QP_solver_Y.X[2], QP_solver_Y.X[3]);

    }
    printf("end\n");
}