/*
 * QP_solver.c
 *
 * Code generation for model "QP_solver".
 *
 * Model version              : 1.667
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Fri Apr 30 01:17:38 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Execution efficiency
 * Validation result: Not run
 */

#include "QP_solver_capi.h"
#include "QP_solver.h"
#include "QP_solver_private.h"

/* Block signals (default storage) */
B_QP_solver_T QP_solver_B;

/* External inputs (root inport signals with default storage) */
ExtU_QP_solver_T QP_solver_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_QP_solver_T QP_solver_Y;

/* Real-time model */
static RT_MODEL_QP_solver_T QP_solver_M_;
RT_MODEL_QP_solver_T *const QP_solver_M = &QP_solver_M_;

/* Forward declaration for local functions */
static void QP_solver_factoryConstruct(int32_T mLB, const real_T lb[4], const
  int32_T indexLB[4], int32_T mUB, const real_T ub[4], const int32_T indexUB[4],
  int32_T mFixed, const int32_T indexFixed[4], sH6iCrytcpDRkZmGBtfsOaB_QP_so_T
  *obj);
static void QP_solv_modifyOverheadPhaseOne_(sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *obj);
static void QP_solver_setProblemType(sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *obj,
  int32_T PROBLEM_TYPE);
static real_T QP_solver_xnrm2(int32_T n, const real_T x[81], int32_T ix0);
static real_T QP_solver_xzlarfg(int32_T n, real_T *alpha1, real_T x[81], int32_T
  ix0);
static void QP_solver_xzlarf(int32_T m, int32_T n, int32_T iv0, real_T tau,
  real_T C[81], int32_T ic0, real_T work[9]);
static void QP_solver_qrf(real_T A[81], int32_T m, int32_T n, int32_T nfxd,
  real_T tau[9]);
static void QP_solver_qrpf(real_T A[81], int32_T m, int32_T n, int32_T nfxd,
  real_T tau[9], int32_T jpvt[9]);
static void QP_solver_xgeqp3(real_T A[81], int32_T m, int32_T n, int32_T jpvt[9],
  real_T tau[9]);
static void QP_solver_computeQ_(s5b283nY1IMTh9oT8JoHmsB_QP_so_T *obj, int32_T
  nrows);
static void QP_solver_factorQRE(s5b283nY1IMTh9oT8JoHmsB_QP_so_T *obj, const
  real_T A[45], int32_T mrows, int32_T ncols);
static void QP_solver_IndexOfDependentEq_(int32_T depIdx[9], int32_T mFixed,
  int32_T nDep, s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager, const real_T
  AeqfPrime[45], int32_T mRows, int32_T nCols);
static void QP_solver_countsort(int32_T x[9], int32_T xLen, int32_T workspace[9],
  int32_T xMin, int32_T xMax);
static void QP_solver_removeConstr(sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *obj, int32_T
  idx_global);
static void QP_solver_removeEqConstr(sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *obj,
  int32_T idx_global);
static void QP_solver_RemoveDependentEq_(s44Ocoq5jREA8hvE3ik8GDG_QP_so_T
  *memspace, sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset, int32_T *nDepInd,
  s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager);
static void QP_solver_removeAllIneqConstr(sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *obj);
static void QP_solver_RemoveDependentIneq_(sH6iCrytcpDRkZmGBtfsOaB_QP_so_T
  *workingset, s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager,
  s44Ocoq5jREA8hvE3ik8GDG_QP_so_T *memspace, real_T tolfactor);
static void QP_solver_factorQR_o(s5b283nY1IMTh9oT8JoHmsB_QP_so_T *obj, const
  real_T A[45], int32_T mrows, int32_T ncols);
static void QP_solver_factorQR(s5b283nY1IMTh9oT8JoHmsB_QP_so_T *obj, int32_T
  mrows, int32_T ncols);
static real_T QP_solve_maxConstraintViolation(const
  sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *obj, const real_T x[45], int32_T ix0);
static boolean_T QP_solv_feasibleX0ForWorkingSet(real_T workspace[45], real_T
  xCurrent[5], const sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset,
  s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager);
static real_T QP_sol_maxConstraintViolation_i(const
  sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *obj, const real_T x[5]);
static void QP_solver_PresolveWorkingSet(sMBHLn8PGyUK14vNDw4vTyG_QP_so_T
  *solution, s44Ocoq5jREA8hvE3ik8GDG_QP_so_T *memspace,
  sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset, s5b283nY1IMTh9oT8JoHmsB_QP_so_T
  *qrmanager, s4lHOiXA0GHbse0IgoBY6ZF_QP_so_T *options);
static void QP_solver_linearForm_(int32_T obj_nvar, real_T workspace[45], const
  real_T H[16], const real_T f[4], const real_T x[5]);
static real_T QP_solver_computeFval(const sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *obj,
  real_T workspace[45], const real_T H[16], const real_T f[4], const real_T x[5]);
static void QP_solver_xgemv(int32_T m, int32_T n, const real_T A[16], int32_T
  lda, const real_T x[5], real_T y[4]);
static void QP_solver_computeGrad_StoreHx(sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *obj,
  const real_T H[16], const real_T f[4], const real_T x[5]);
static real_T QP_solver_computeFval_ReuseHx(const
  sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *obj, real_T workspace[45], const real_T f[4],
  const real_T x[5]);
static void QP_solver_xrotg(real_T *a, real_T *b, real_T *c, real_T *s);
static void QP_solver_squareQ_appendCol(s5b283nY1IMTh9oT8JoHmsB_QP_so_T *obj,
  const real_T vec[45], int32_T iv0);
static void QP_solver_deleteColMoveEnd(s5b283nY1IMTh9oT8JoHmsB_QP_so_T *obj,
  int32_T idx);
static void QP_solver_xgemm(int32_T m, int32_T n, int32_T k, const real_T A[16],
  int32_T lda, const real_T B[81], int32_T ib0, real_T C[45]);
static void QP_solver_xgemm_e(int32_T m, int32_T n, int32_T k, const real_T A[81],
  int32_T ia0, const real_T B[45], real_T C[81]);
static void QP_solver_fullColLDL2_(sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T *obj, int32_T
  LD_offset, int32_T NColsRemain, real_T REG_PRIMAL);
static void QP_solver_xgemv_c(int32_T m, int32_T n, const real_T A[81], int32_T
  ia0, const real_T x[45], real_T y[5]);
static void QP_solver_partialColLDL3_(sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T *obj,
  int32_T LD_offset, int32_T NColsRemain, real_T REG_PRIMAL);
static int32_T QP_solver_ixamax(int32_T n, const real_T x[81]);
static void QP_solver_factor(sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T *obj, const real_T
  A[16], int32_T ndims, int32_T ldA);
static void QP_solver_solve(const sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T *obj, real_T
  rhs[5]);
static void QP_solver_compute_deltax(const real_T H[16],
  sMBHLn8PGyUK14vNDw4vTyG_QP_so_T *solution, s44Ocoq5jREA8hvE3ik8GDG_QP_so_T
  *memspace, const s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager,
  sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T *cholmanager, const
  sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *objective);
static real_T QP_solver_xnrm2_c(int32_T n, const real_T x[5]);
static void QP_solver_feasibleratiotest(const real_T solution_xstar[5], const
  real_T solution_searchDir[5], int32_T workingset_nVar, const real_T
  workingset_lb[5], const real_T workingset_ub[5], const int32_T
  workingset_indexLB[5], const int32_T workingset_indexUB[5], const int32_T
  workingset_sizes[5], const int32_T workingset_isActiveIdx[6], const boolean_T
  workingset_isActiveConstr[9], const int32_T workingset_nWConstr[5], boolean_T
  isPhaseOne, real_T *alpha, boolean_T *newBlocking, int32_T *constrType,
  int32_T *constrIdx);
static void QP_sol_checkUnboundedOrIllPosed(sMBHLn8PGyUK14vNDw4vTyG_QP_so_T
  *solution, const sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *objective);
static void QP_s_addBoundToActiveSetMatrix_(sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *obj,
  int32_T TYPE, int32_T idx_local);
static void QP_solver_compute_lambda(real_T workspace[45],
  sMBHLn8PGyUK14vNDw4vTyG_QP_so_T *solution, const
  sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *objective, const
  s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager);
static void QP_s_checkStoppingAndUpdateFval(int32_T *activeSetChangeID, const
  real_T f[4], sMBHLn8PGyUK14vNDw4vTyG_QP_so_T *solution,
  s44Ocoq5jREA8hvE3ik8GDG_QP_so_T *memspace, const
  sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *objective, const
  sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset, s5b283nY1IMTh9oT8JoHmsB_QP_so_T
  *qrmanager, real_T options_ObjectiveLimit, int32_T
  runTimeOptions_MaxIterations, boolean_T updateFval);
static void QP_solver_iterate(const real_T H[16], const real_T f[4],
  sMBHLn8PGyUK14vNDw4vTyG_QP_so_T *solution, s44Ocoq5jREA8hvE3ik8GDG_QP_so_T
  *memspace, sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset,
  s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager, sPZu81U7pb4xx4nEpbF8lJH_QP_so_T
  *objective, real_T options_ObjectiveLimit, int32_T
  runTimeOptions_MaxIterations, real_T runTimeOptions_ProbRelTolFactor,
  sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T *cholmanager);
static void QP_solver_phaseone(const real_T H[16], const real_T f[4],
  sMBHLn8PGyUK14vNDw4vTyG_QP_so_T *solution, s44Ocoq5jREA8hvE3ik8GDG_QP_so_T
  *memspace, sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset,
  s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager, s4lHOiXA0GHbse0IgoBY6ZF_QP_so_T
  *options, const sL9bDKomAYkxZSVrG9w6En_QP_sol_T *runTimeOptions,
  sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T *cholmanager, sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *
  objective);
static int32_T QP_solver_RemoveDependentEq__c(s44Ocoq5jREA8hvE3ik8GDG_QP_so_T
  *memspace, sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset,
  s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager);
static void QP_solver_PresolveWorkingSet_i(sMBHLn8PGyUK14vNDw4vTyG_QP_so_T
  *solution, s44Ocoq5jREA8hvE3ik8GDG_QP_so_T *memspace,
  sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset, s5b283nY1IMTh9oT8JoHmsB_QP_so_T
  *qrmanager);
static void QP_solver_iterate_n(const real_T H[16], const real_T f[4],
  sMBHLn8PGyUK14vNDw4vTyG_QP_so_T *solution, s44Ocoq5jREA8hvE3ik8GDG_QP_so_T
  *memspace, sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset,
  s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager, sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T
  *cholmanager, sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *objective, real_T
  options_ObjectiveLimit, real_T options_StepTolerance, int32_T
  runTimeOptions_MaxIterations, real_T runTimeOptions_ProbRelTolFactor,
  boolean_T runTimeOptions_RemainFeasible);
static boolean_T QP_solver_strcmp(const char_T a[8]);
static void QP_solver_computeFirstOrderOpt(sMBHLn8PGyUK14vNDw4vTyG_QP_so_T
  *solution, const sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *objective, int32_T
  workingset_nVar, const real_T workingset_ATwset[45], int32_T
  workingset_nActiveConstr, real_T workspace[45]);
static void QP_solver_phaseone_k(const real_T H[16], const real_T f[4],
  sMBHLn8PGyUK14vNDw4vTyG_QP_so_T *solution, s44Ocoq5jREA8hvE3ik8GDG_QP_so_T
  *memspace, sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset,
  s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager, sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T
  *cholmanager, sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *objective,
  s4lHOiXA0GHbse0IgoBY6ZF_QP_so_T *options, const
  sL9bDKomAYkxZSVrG9w6En_QP_sol_T *runTimeOptions);
static void QP_solver_driver(const real_T H[16], const real_T f[4],
  sMBHLn8PGyUK14vNDw4vTyG_QP_so_T *solution, s44Ocoq5jREA8hvE3ik8GDG_QP_so_T
  *memspace, sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset,
  sL9bDKomAYkxZSVrG9w6En_QP_sol_T runTimeOptions,
  s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager, sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T
  *cholmanager, sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *objective);
static void QP_solver_quadprog(const real_T H[16], const real_T f[4], const
  real_T lb[4], const real_T ub[4], real_T x[4]);

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_factoryConstruct(int32_T mLB, const real_T lb[4], const
  int32_T indexLB[4], int32_T mUB, const real_T ub[4], const int32_T indexUB[4],
  int32_T mFixed, const int32_T indexFixed[4], sH6iCrytcpDRkZmGBtfsOaB_QP_so_T
  *obj)
{
  int32_T x[6];
  int32_T x_tmp[6];
  int32_T x_tmp_0[6];
  int32_T obj_tmp[5];
  int32_T obj_tmp_0[5];
  int32_T i;
  int32_T obj_tmp_1;
  int32_T obj_tmp_2;
  obj_tmp_2 = (mLB + mUB) + mFixed;
  obj->mConstr = obj_tmp_2;
  obj->mConstrOrig = obj_tmp_2;
  obj->mConstrMax = 9;
  obj->nVar = 4;
  obj->nVarOrig = 4;
  obj->nVarMax = 5;
  obj->ldA = 5;
  obj->mEqRemoved = 0;
  obj->nActiveConstr = 0;
  obj_tmp[0] = mFixed;
  obj_tmp[1] = 0;
  obj_tmp[2] = 0;
  obj_tmp[3] = mLB;
  obj_tmp[4] = mUB;
  obj_tmp_0[0] = mFixed;
  obj_tmp_0[1] = 0;
  obj_tmp_0[2] = 0;
  obj_tmp_0[3] = mLB + 1;
  obj_tmp_0[4] = mUB;
  for (i = 0; i < 5; i++) {
    obj_tmp_2 = obj_tmp_0[i];
    obj_tmp_1 = obj_tmp[i];
    obj->sizes[i] = obj_tmp_1;
    obj->sizesNormal[i] = obj_tmp_1;
    obj->sizesPhaseOne[i] = obj_tmp_2;
    obj->sizesRegularized[i] = obj_tmp_1;
    obj->sizesRegPhaseOne[i] = obj_tmp_2;
  }

  x_tmp[0] = 1;
  x_tmp[1] = mFixed;
  x_tmp[2] = 0;
  x_tmp[3] = 0;
  x_tmp[4] = mLB;
  x_tmp[5] = mUB;
  for (i = 0; i < 6; i++) {
    x[i] = x_tmp[i];
  }

  for (obj_tmp_2 = 0; obj_tmp_2 < 5; obj_tmp_2++) {
    x[obj_tmp_2 + 1] += x[obj_tmp_2];
  }

  for (i = 0; i < 6; i++) {
    obj->isActiveIdx[i] = x[i];
    x[i] = x_tmp[i];
  }

  for (obj_tmp_2 = 0; obj_tmp_2 < 5; obj_tmp_2++) {
    x[obj_tmp_2 + 1] += x[obj_tmp_2];
  }

  x_tmp_0[0] = 1;
  x_tmp_0[1] = mFixed;
  x_tmp_0[2] = 0;
  x_tmp_0[3] = 0;
  x_tmp_0[4] = mLB + 1;
  x_tmp_0[5] = mUB;
  for (i = 0; i < 6; i++) {
    obj->isActiveIdxNormal[i] = x[i];
    x[i] = x_tmp_0[i];
  }

  for (obj_tmp_2 = 0; obj_tmp_2 < 5; obj_tmp_2++) {
    x[obj_tmp_2 + 1] += x[obj_tmp_2];
  }

  for (i = 0; i < 6; i++) {
    obj->isActiveIdxPhaseOne[i] = x[i];
    x[i] = x_tmp[i];
  }

  for (obj_tmp_2 = 0; obj_tmp_2 < 5; obj_tmp_2++) {
    x[obj_tmp_2 + 1] += x[obj_tmp_2];
  }

  for (i = 0; i < 6; i++) {
    obj->isActiveIdxRegularized[i] = x[i];
    x[i] = x_tmp_0[i];
  }

  for (obj_tmp_2 = 0; obj_tmp_2 < 5; obj_tmp_2++) {
    x[obj_tmp_2 + 1] += x[obj_tmp_2];
  }

  for (i = 0; i < 6; i++) {
    obj->isActiveIdxRegPhaseOne[i] = x[i];
  }

  for (i = 0; i < 5; i++) {
    obj->nWConstr[i] = 0;
  }

  obj->probType = 3;
  obj->SLACK0 = 1.0E-5;
  obj->lb[0] = -lb[0];
  obj->ub[0] = ub[0];
  obj->lb[1] = -lb[1];
  obj->ub[1] = ub[1];
  obj->lb[2] = -lb[2];
  obj->ub[2] = ub[2];
  obj->lb[3] = -lb[3];
  obj->ub[3] = ub[3];
  for (obj_tmp_2 = 0; obj_tmp_2 < mLB; obj_tmp_2++) {
    obj->indexLB[obj_tmp_2] = indexLB[obj_tmp_2];
  }

  for (obj_tmp_2 = 0; obj_tmp_2 < mUB; obj_tmp_2++) {
    obj->indexUB[obj_tmp_2] = indexUB[obj_tmp_2];
  }

  for (obj_tmp_2 = 0; obj_tmp_2 < mFixed; obj_tmp_2++) {
    obj->indexFixed[obj_tmp_2] = indexFixed[obj_tmp_2];
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solv_modifyOverheadPhaseOne_(sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *obj)
{
  int32_T idx;
  for (idx = 0; idx < obj->sizes[0]; idx++) {
    obj->ATwset[5 * idx + 4] = 0.0;
  }

  obj->indexLB[obj->sizes[3] - 1] = 5;
  obj->lb[4] = obj->SLACK0;
  for (idx = obj->isActiveIdx[2]; idx <= obj->nActiveConstr; idx++) {
    obj->ATwset[5 * (idx - 1) + 4] = -1.0;
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_setProblemType(sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *obj,
  int32_T PROBLEM_TYPE)
{
  int32_T idx;
  int32_T idx_lb;
  switch (PROBLEM_TYPE) {
   case 3:
    obj->nVar = 4;
    obj->mConstr = obj->mConstrOrig;
    for (idx_lb = 0; idx_lb < 5; idx_lb++) {
      obj->sizes[idx_lb] = obj->sizesNormal[idx_lb];
    }

    for (idx_lb = 0; idx_lb < 6; idx_lb++) {
      obj->isActiveIdx[idx_lb] = obj->isActiveIdxNormal[idx_lb];
    }
    break;

   case 1:
    obj->nVar = 5;
    obj->mConstr = obj->mConstrOrig + 1;
    for (idx_lb = 0; idx_lb < 5; idx_lb++) {
      obj->sizes[idx_lb] = obj->sizesPhaseOne[idx_lb];
    }

    for (idx_lb = 0; idx_lb < 6; idx_lb++) {
      obj->isActiveIdx[idx_lb] = obj->isActiveIdxPhaseOne[idx_lb];
    }

    QP_solv_modifyOverheadPhaseOne_(obj);
    break;

   case 2:
    obj->nVar = 4;
    obj->mConstr = 8;
    for (idx_lb = 0; idx_lb < 5; idx_lb++) {
      obj->sizes[idx_lb] = obj->sizesRegularized[idx_lb];
    }

    for (idx_lb = 0; idx_lb < 6; idx_lb++) {
      obj->isActiveIdx[idx_lb] = obj->isActiveIdxRegularized[idx_lb];
    }

    if (obj->probType != 4) {
      idx_lb = 4;
      for (idx = obj->sizesNormal[3]; idx < obj->sizesRegularized[3]; idx++) {
        idx_lb++;
        obj->indexLB[idx] = idx_lb;
      }

      for (idx_lb = obj->isActiveIdx[2] - 1; idx_lb < obj->nActiveConstr; idx_lb
           ++) {
        if (obj->Wid[idx_lb] == 3) {
          for (idx = 5; idx <= obj->Wlocalidx[idx_lb] + 3; idx++) {
            obj->ATwset[5 * idx_lb + 4] = 0.0;
          }

          obj->ATwset[(obj->Wlocalidx[idx_lb] + 5 * idx_lb) + 3] = -1.0;
          for (idx = obj->Wlocalidx[idx_lb] + 4; idx + 1 < 5; idx++) {
            obj->ATwset[idx + 5 * idx_lb] = 0.0;
          }
        }
      }
    }
    break;

   default:
    obj->nVar = 5;
    obj->mConstr = 9;
    for (idx_lb = 0; idx_lb < 5; idx_lb++) {
      obj->sizes[idx_lb] = obj->sizesRegPhaseOne[idx_lb];
    }

    for (idx_lb = 0; idx_lb < 6; idx_lb++) {
      obj->isActiveIdx[idx_lb] = obj->isActiveIdxRegPhaseOne[idx_lb];
    }

    QP_solv_modifyOverheadPhaseOne_(obj);
    break;
  }

  obj->probType = PROBLEM_TYPE;
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static real_T QP_solver_xnrm2(int32_T n, const real_T x[81], int32_T ix0)
{
  real_T absxk;
  real_T scale;
  real_T t;
  real_T y;
  int32_T k;
  int32_T kend;
  y = 0.0;
  if (n >= 1) {
    if (n == 1) {
      y = fabs(x[ix0 - 1]);
    } else {
      scale = 3.3121686421112381E-170;
      kend = (ix0 + n) - 1;
      for (k = ix0; k <= kend; k++) {
        absxk = fabs(x[k - 1]);
        if (absxk > scale) {
          t = scale / absxk;
          y = y * t * t + 1.0;
          scale = absxk;
        } else {
          t = absxk / scale;
          y += t * t;
        }
      }

      y = scale * sqrt(y);
    }
  }

  return y;
}

real_T rt_hypotd_snf(real_T u0, real_T u1)
{
  real_T a;
  real_T y;
  a = fabs(u0);
  y = fabs(u1);
  if (a < y) {
    a /= y;
    y *= sqrt(a * a + 1.0);
  } else if (a > y) {
    y /= a;
    y = sqrt(y * y + 1.0) * a;
  } else {
    if (!rtIsNaN(y)) {
      y = a * 1.4142135623730951;
    }
  }

  return y;
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static real_T QP_solver_xzlarfg(int32_T n, real_T *alpha1, real_T x[81], int32_T
  ix0)
{
  real_T tau;
  real_T xnorm;
  int32_T b_k;
  int32_T c_k;
  int32_T knt;
  tau = 0.0;
  if (n > 0) {
    xnorm = QP_solver_xnrm2(n - 1, x, ix0);
    if (xnorm != 0.0) {
      xnorm = rt_hypotd_snf(*alpha1, xnorm);
      if (*alpha1 >= 0.0) {
        xnorm = -xnorm;
      }

      if (fabs(xnorm) < 1.0020841800044864E-292) {
        knt = -1;
        b_k = (ix0 + n) - 2;
        do {
          knt++;
          for (c_k = ix0; c_k <= b_k; c_k++) {
            x[c_k - 1] *= 9.9792015476736E+291;
          }

          xnorm *= 9.9792015476736E+291;
          *alpha1 *= 9.9792015476736E+291;
        } while (!(fabs(xnorm) >= 1.0020841800044864E-292));

        xnorm = rt_hypotd_snf(*alpha1, QP_solver_xnrm2(n - 1, x, ix0));
        if (*alpha1 >= 0.0) {
          xnorm = -xnorm;
        }

        tau = (xnorm - *alpha1) / xnorm;
        *alpha1 = 1.0 / (*alpha1 - xnorm);
        for (c_k = ix0; c_k <= b_k; c_k++) {
          x[c_k - 1] *= *alpha1;
        }

        for (b_k = 0; b_k <= knt; b_k++) {
          xnorm *= 1.0020841800044864E-292;
        }

        *alpha1 = xnorm;
      } else {
        tau = (xnorm - *alpha1) / xnorm;
        *alpha1 = 1.0 / (*alpha1 - xnorm);
        knt = (ix0 + n) - 2;
        for (b_k = ix0; b_k <= knt; b_k++) {
          x[b_k - 1] *= *alpha1;
        }

        *alpha1 = xnorm;
      }
    }
  }

  return tau;
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_xzlarf(int32_T m, int32_T n, int32_T iv0, real_T tau,
  real_T C[81], int32_T ic0, real_T work[9])
{
  real_T c;
  int32_T coltop;
  int32_T d;
  int32_T exitg1;
  int32_T ia;
  int32_T iac;
  int32_T ix;
  int32_T jy;
  int32_T lastc;
  int32_T lastv;
  boolean_T exitg2;
  if (tau != 0.0) {
    lastv = m;
    lastc = iv0 + m;
    while ((lastv > 0) && (C[lastc - 2] == 0.0)) {
      lastv--;
      lastc--;
    }

    lastc = n - 1;
    exitg2 = false;
    while ((!exitg2) && (lastc + 1 > 0)) {
      coltop = lastc * 9 + ic0;
      jy = coltop;
      do {
        exitg1 = 0;
        if (jy <= (coltop + lastv) - 1) {
          if (C[jy - 1] != 0.0) {
            exitg1 = 1;
          } else {
            jy++;
          }
        } else {
          lastc--;
          exitg1 = 2;
        }
      } while (exitg1 == 0);

      if (exitg1 == 1) {
        exitg2 = true;
      }
    }
  } else {
    lastv = 0;
    lastc = -1;
  }

  if (lastv > 0) {
    if (lastc + 1 != 0) {
      for (coltop = 0; coltop <= lastc; coltop++) {
        work[coltop] = 0.0;
      }

      coltop = 0;
      jy = 9 * lastc + ic0;
      for (iac = ic0; iac <= jy; iac += 9) {
        ix = iv0;
        c = 0.0;
        d = (iac + lastv) - 1;
        for (ia = iac; ia <= d; ia++) {
          c += C[ia - 1] * C[ix - 1];
          ix++;
        }

        work[coltop] += c;
        coltop++;
      }
    }

    if (!(-tau == 0.0)) {
      coltop = ic0 - 1;
      jy = 0;
      for (iac = 0; iac <= lastc; iac++) {
        if (work[jy] != 0.0) {
          c = work[jy] * -tau;
          ix = iv0;
          d = lastv + coltop;
          for (ia = coltop; ia < d; ia++) {
            C[ia] += C[ix - 1] * c;
            ix++;
          }
        }

        jy++;
        coltop += 9;
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_qrf(real_T A[81], int32_T m, int32_T n, int32_T nfxd,
  real_T tau[9])
{
  real_T work[9];
  real_T b_atmp;
  int32_T i;
  int32_T ii;
  int32_T mmi;
  memset(&work[0], 0, 9U * sizeof(real_T));
  for (i = 0; i < nfxd; i++) {
    ii = i * 9 + i;
    mmi = m - i;
    if (i + 1 < m) {
      b_atmp = A[ii];
      tau[i] = QP_solver_xzlarfg(mmi, &b_atmp, A, ii + 2);
      A[ii] = b_atmp;
    } else {
      tau[i] = 0.0;
    }

    if (i + 1 < n) {
      b_atmp = A[ii];
      A[ii] = 1.0;
      QP_solver_xzlarf(mmi, (n - i) - 1, ii + 1, tau[i], A, ii + 10, work);
      A[ii] = b_atmp;
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_qrpf(real_T A[81], int32_T m, int32_T n, int32_T nfxd,
  real_T tau[9], int32_T jpvt[9])
{
  real_T vn1[9];
  real_T vn2[9];
  real_T work[9];
  real_T smax;
  real_T temp2;
  int32_T b_k;
  int32_T ii;
  int32_T ix;
  int32_T iy;
  int32_T j;
  int32_T minmn;
  int32_T mmi;
  int32_T nmi;
  int32_T pvt;
  if (m < n) {
    minmn = m;
  } else {
    minmn = n;
  }

  memset(&work[0], 0, 9U * sizeof(real_T));
  memset(&vn1[0], 0, 9U * sizeof(real_T));
  memset(&vn2[0], 0, 9U * sizeof(real_T));
  for (j = nfxd; j < n; j++) {
    vn1[j] = QP_solver_xnrm2(m - nfxd, A, (j * 9 + nfxd) + 1);
    vn2[j] = vn1[j];
  }

  for (j = nfxd; j < minmn; j++) {
    ii = j * 9 + j;
    nmi = n - j;
    mmi = m - j;
    if (nmi < 1) {
      pvt = -1;
    } else {
      pvt = 0;
      if (nmi > 1) {
        ix = j;
        smax = fabs(vn1[j]);
        for (iy = 2; iy <= nmi; iy++) {
          ix++;
          temp2 = fabs(vn1[ix]);
          if (temp2 > smax) {
            pvt = iy - 1;
            smax = temp2;
          }
        }
      }
    }

    pvt += j;
    if (pvt + 1 != j + 1) {
      ix = pvt * 9;
      iy = j * 9;
      for (b_k = 0; b_k < m; b_k++) {
        smax = A[ix];
        A[ix] = A[iy];
        A[iy] = smax;
        ix++;
        iy++;
      }

      ix = jpvt[pvt];
      jpvt[pvt] = jpvt[j];
      jpvt[j] = ix;
      vn1[pvt] = vn1[j];
      vn2[pvt] = vn2[j];
    }

    if (j + 1 < m) {
      smax = A[ii];
      tau[j] = QP_solver_xzlarfg(mmi, &smax, A, ii + 2);
      A[ii] = smax;
    } else {
      tau[j] = 0.0;
    }

    if (j + 1 < n) {
      smax = A[ii];
      A[ii] = 1.0;
      QP_solver_xzlarf(mmi, nmi - 1, ii + 1, tau[j], A, ii + 10, work);
      A[ii] = smax;
    }

    for (ii = j + 1; ii < n; ii++) {
      nmi = ii * 9 + j;
      if (vn1[ii] != 0.0) {
        smax = fabs(A[nmi]) / vn1[ii];
        smax = 1.0 - smax * smax;
        if (smax < 0.0) {
          smax = 0.0;
        }

        temp2 = vn1[ii] / vn2[ii];
        temp2 = temp2 * temp2 * smax;
        if (temp2 <= 1.4901161193847656E-8) {
          if (j + 1 < m) {
            vn1[ii] = QP_solver_xnrm2(mmi - 1, A, nmi + 2);
            vn2[ii] = vn1[ii];
          } else {
            vn1[ii] = 0.0;
            vn2[ii] = 0.0;
          }
        } else {
          vn1[ii] *= sqrt(smax);
        }
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_xgeqp3(real_T A[81], int32_T m, int32_T n, int32_T jpvt[9],
  real_T tau[9])
{
  real_T temp;
  int32_T c_j;
  int32_T ix;
  int32_T iy;
  int32_T k;
  int32_T minmn;
  int32_T nfxd;
  if (m < n) {
    minmn = m;
  } else {
    minmn = n;
  }

  memset(&tau[0], 0, 9U * sizeof(real_T));
  if (minmn < 1) {
    for (minmn = 0; minmn < n; minmn++) {
      jpvt[minmn] = minmn + 1;
    }
  } else {
    nfxd = -1;
    for (c_j = 0; c_j < n; c_j++) {
      if (jpvt[c_j] != 0) {
        nfxd++;
        if (c_j + 1 != nfxd + 1) {
          ix = c_j * 9;
          iy = nfxd * 9;
          for (k = 0; k < m; k++) {
            temp = A[ix];
            A[ix] = A[iy];
            A[iy] = temp;
            ix++;
            iy++;
          }

          jpvt[c_j] = jpvt[nfxd];
          jpvt[nfxd] = c_j + 1;
        } else {
          jpvt[c_j] = c_j + 1;
        }
      } else {
        jpvt[c_j] = c_j + 1;
      }
    }

    if (nfxd + 1 < minmn) {
      nfxd++;
    } else {
      nfxd = minmn;
    }

    memset(&tau[0], 0, 9U * sizeof(real_T));
    QP_solver_qrf(A, m, n, nfxd, tau);
    if (nfxd < minmn) {
      QP_solver_qrpf(A, m, n, nfxd, tau, jpvt);
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_computeQ_(s5b283nY1IMTh9oT8JoHmsB_QP_so_T *obj, int32_T
  nrows)
{
  real_T A[81];
  real_T work[9];
  real_T c_c;
  int32_T coltop;
  int32_T e;
  int32_T exitg1;
  int32_T i;
  int32_T ia;
  int32_T iac;
  int32_T iaii;
  int32_T idx;
  int32_T itau;
  int32_T ix;
  int32_T jy;
  int32_T lastc;
  int32_T lastv;
  boolean_T exitg2;
  for (idx = 0; idx < obj->minRowCol; idx++) {
    itau = 9 * idx + idx;
    i = obj->mrows - idx;
    for (iaii = 1; iaii - 1 <= i - 2; iaii++) {
      lastv = itau + iaii;
      obj->Q[lastv] = obj->QR[lastv];
    }
  }

  idx = obj->mrows;
  if (nrows >= 1) {
    for (itau = obj->minRowCol; itau < nrows; itau++) {
      i = itau * 9;
      for (iaii = 0; iaii < idx; iaii++) {
        obj->Q[i + iaii] = 0.0;
      }

      obj->Q[i + itau] = 1.0;
    }

    itau = obj->minRowCol - 1;
    memset(&work[0], 0, 9U * sizeof(real_T));
    for (i = obj->minRowCol; i >= 1; i--) {
      iaii = (i - 1) * 9 + i;
      if (i < nrows) {
        obj->Q[iaii - 1] = 1.0;
        lastv = idx - i;
        memcpy(&A[0], &obj->Q[0], 81U * sizeof(real_T));
        if (obj->tau[itau] != 0.0) {
          lastc = iaii + lastv;
          while ((lastv + 1 > 0) && (obj->Q[lastc - 1] == 0.0)) {
            lastv--;
            lastc--;
          }

          lastc = (nrows - i) - 1;
          exitg2 = false;
          while ((!exitg2) && (lastc + 1 > 0)) {
            coltop = (lastc * 9 + iaii) + 9;
            jy = coltop;
            do {
              exitg1 = 0;
              if (jy <= coltop + lastv) {
                if (obj->Q[jy - 1] != 0.0) {
                  exitg1 = 1;
                } else {
                  jy++;
                }
              } else {
                lastc--;
                exitg1 = 2;
              }
            } while (exitg1 == 0);

            if (exitg1 == 1) {
              exitg2 = true;
            }
          }
        } else {
          lastv = -1;
          lastc = -1;
        }

        if (lastv + 1 > 0) {
          if (lastc + 1 != 0) {
            for (coltop = 0; coltop <= lastc; coltop++) {
              work[coltop] = 0.0;
            }

            coltop = 0;
            jy = (9 * lastc + iaii) + 9;
            for (iac = iaii + 9; iac <= jy; iac += 9) {
              ix = iaii;
              c_c = 0.0;
              e = iac + lastv;
              for (ia = iac; ia <= e; ia++) {
                c_c += obj->Q[ia - 1] * obj->Q[ix - 1];
                ix++;
              }

              work[coltop] += c_c;
              coltop++;
            }
          }

          if (!(-obj->tau[itau] == 0.0)) {
            coltop = iaii + 8;
            jy = 0;
            for (iac = 0; iac <= lastc; iac++) {
              if (work[jy] != 0.0) {
                c_c = work[jy] * -obj->tau[itau];
                ix = iaii;
                e = lastv + coltop;
                for (ia = coltop; ia < e + 1; ia++) {
                  A[ia] += A[ix - 1] * c_c;
                  ix++;
                }
              }

              jy++;
              coltop += 9;
            }
          }
        }

        memcpy(&obj->Q[0], &A[0], 81U * sizeof(real_T));
      }

      if (i < idx) {
        lastv = (iaii + idx) - i;
        for (lastc = iaii; lastc < lastv; lastc++) {
          obj->Q[lastc] *= -obj->tau[itau];
        }
      }

      obj->Q[iaii - 1] = 1.0 - obj->tau[itau];
      for (lastv = 0; lastv <= i - 2; lastv++) {
        obj->Q[(iaii - lastv) - 2] = 0.0;
      }

      itau--;
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_factorQRE(s5b283nY1IMTh9oT8JoHmsB_QP_so_T *obj, const
  real_T A[45], int32_T mrows, int32_T ncols)
{
  real_T b[81];
  real_T c[9];
  int32_T d[9];
  int32_T i;
  int32_T iA0;
  int32_T iQR0;
  int32_T k;
  boolean_T guard1 = false;
  i = mrows * ncols;
  guard1 = false;
  if (i > 0) {
    for (i = 0; i < ncols; i++) {
      iA0 = 5 * i;
      iQR0 = 9 * i;
      for (k = 1; k - 1 < mrows; k++) {
        obj->QR[(iQR0 + k) - 1] = A[(iA0 + k) - 1];
      }
    }

    guard1 = true;
  } else if (i == 0) {
    obj->mrows = mrows;
    obj->ncols = ncols;
    obj->minRowCol = 0;
  } else {
    guard1 = true;
  }

  if (guard1) {
    obj->usedPivoting = true;
    obj->mrows = mrows;
    obj->ncols = ncols;
    if (mrows < ncols) {
      obj->minRowCol = mrows;
    } else {
      obj->minRowCol = ncols;
    }

    memcpy(&b[0], &obj->QR[0], 81U * sizeof(real_T));
    for (i = 0; i < 9; i++) {
      d[i] = obj->jpvt[i];
    }

    QP_solver_xgeqp3(b, mrows, ncols, d, c);
    memcpy(&obj->QR[0], &b[0], 81U * sizeof(real_T));
    memcpy(&obj->tau[0], &c[0], 9U * sizeof(real_T));
    for (i = 0; i < 9; i++) {
      obj->jpvt[i] = d[i];
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_IndexOfDependentEq_(int32_T depIdx[9], int32_T mFixed,
  int32_T nDep, s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager, const real_T
  AeqfPrime[45], int32_T mRows, int32_T nCols)
{
  int32_T b_idx;
  for (b_idx = 0; b_idx < mFixed; b_idx++) {
    qrmanager->jpvt[b_idx] = 1;
  }

  for (b_idx = mFixed; b_idx < nCols; b_idx++) {
    qrmanager->jpvt[b_idx] = 0;
  }

  QP_solver_factorQRE(qrmanager, AeqfPrime, mRows, nCols);
  for (b_idx = 0; b_idx < nDep; b_idx++) {
    depIdx[b_idx] = qrmanager->jpvt[(nCols - nDep) + b_idx];
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_countsort(int32_T x[9], int32_T xLen, int32_T workspace[9],
  int32_T xMin, int32_T xMax)
{
  int32_T b_idxW;
  int32_T idxEnd;
  int32_T idxStart;
  int32_T maxOffset_tmp;
  if ((xLen > 1) && (xMax > xMin)) {
    maxOffset_tmp = xMax - xMin;
    for (idxStart = 0; idxStart <= maxOffset_tmp; idxStart++) {
      workspace[idxStart] = 0;
    }

    for (idxStart = 0; idxStart < xLen; idxStart++) {
      idxEnd = x[idxStart] - xMin;
      workspace[idxEnd]++;
    }

    for (idxStart = 1; idxStart < maxOffset_tmp + 1; idxStart++) {
      workspace[idxStart] += workspace[idxStart - 1];
    }

    idxStart = 0;
    idxEnd = workspace[0];
    for (b_idxW = 0; b_idxW < maxOffset_tmp; b_idxW++) {
      while (idxStart + 1 <= idxEnd) {
        x[idxStart] = b_idxW + xMin;
        idxStart++;
      }

      idxStart = workspace[b_idxW];
      idxEnd = workspace[b_idxW + 1];
    }

    while (idxStart + 1 <= idxEnd) {
      x[idxStart] = xMax;
      idxStart++;
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_removeConstr(sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *obj, int32_T
  idx_global)
{
  int32_T TYPE_tmp;
  int32_T b_idx;
  int32_T idx_global_start;
  TYPE_tmp = obj->Wid[idx_global - 1] - 1;
  obj->isActiveConstr[(obj->isActiveIdx[TYPE_tmp] + obj->Wlocalidx[idx_global -
                       1]) - 2] = false;
  idx_global_start = obj->nActiveConstr - 1;
  obj->Wid[idx_global - 1] = obj->Wid[obj->nActiveConstr - 1];
  obj->Wlocalidx[idx_global - 1] = obj->Wlocalidx[idx_global_start];
  for (b_idx = 0; b_idx < obj->nVar; b_idx++) {
    obj->ATwset[b_idx + 5 * (idx_global - 1)] = obj->ATwset[5 * idx_global_start
      + b_idx];
  }

  obj->bwset[idx_global - 1] = obj->bwset[idx_global_start];
  obj->nActiveConstr--;
  obj->nWConstr[TYPE_tmp]--;
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_removeEqConstr(sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *obj,
  int32_T idx_global)
{
  int32_T TYPE_tmp;
  int32_T b_idx;
  int32_T d_idx;
  int32_T totalEq;
  totalEq = (obj->nWConstr[0] + obj->nWConstr[1]) - 1;
  if ((totalEq + 1 != 0) && (idx_global <= totalEq + 1)) {
    if ((totalEq + 1 == obj->nActiveConstr) || (totalEq + 1 == idx_global)) {
      obj->mEqRemoved++;
      QP_solver_removeConstr(obj, idx_global);
    } else {
      obj->mEqRemoved++;
      TYPE_tmp = obj->Wid[idx_global - 1] - 1;
      obj->isActiveConstr[(obj->isActiveIdx[TYPE_tmp] + obj->
                           Wlocalidx[idx_global - 1]) - 2] = false;
      obj->Wid[idx_global - 1] = obj->Wid[totalEq];
      obj->Wlocalidx[idx_global - 1] = obj->Wlocalidx[totalEq];
      for (b_idx = 0; b_idx < obj->nVar; b_idx++) {
        obj->ATwset[b_idx + 5 * (idx_global - 1)] = obj->ATwset[5 * totalEq +
          b_idx];
      }

      obj->bwset[idx_global - 1] = obj->bwset[totalEq];
      b_idx = obj->nActiveConstr - 1;
      obj->Wid[totalEq] = obj->Wid[obj->nActiveConstr - 1];
      obj->Wlocalidx[totalEq] = obj->Wlocalidx[b_idx];
      for (d_idx = 0; d_idx < obj->nVar; d_idx++) {
        obj->ATwset[d_idx + 5 * totalEq] = obj->ATwset[5 * b_idx + d_idx];
      }

      obj->bwset[totalEq] = obj->bwset[b_idx];
      obj->nActiveConstr--;
      obj->nWConstr[TYPE_tmp]--;
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_RemoveDependentEq_(s44Ocoq5jREA8hvE3ik8GDG_QP_so_T
  *memspace, sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset, int32_T *nDepInd,
  s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager)
{
  real_T c[81];
  real_T qtb;
  real_T tol;
  int32_T b[9];
  int32_T e[9];
  int32_T i;
  int32_T ix;
  int32_T iy;
  int32_T k;
  int32_T mWorkingFixed;
  boolean_T exitg1;
  qrmanager->ldq = 9;
  memset(&qrmanager->QR[0], 0, 81U * sizeof(real_T));
  memset(&qrmanager->Q[0], 0, 81U * sizeof(real_T));
  qrmanager->mrows = 0;
  qrmanager->ncols = 0;
  memset(&qrmanager->tau[0], 0, 9U * sizeof(real_T));
  for (i = 0; i < 9; i++) {
    qrmanager->jpvt[i] = 0;
  }

  qrmanager->minRowCol = 0;
  qrmanager->usedPivoting = false;
  i = workingset->nVar - 1;
  mWorkingFixed = workingset->nWConstr[0] - 1;
  *nDepInd = 0;
  if (workingset->nWConstr[0] > 0) {
    for (ix = 0; ix <= mWorkingFixed; ix++) {
      for (k = 0; k <= i; k++) {
        qrmanager->QR[ix + 9 * k] = workingset->ATwset[5 * ix + k];
      }
    }

    for (ix = 0; ix <= i; ix++) {
      qrmanager->jpvt[ix] = 0;
    }

    qrmanager->usedPivoting = true;
    qrmanager->mrows = workingset->nWConstr[0];
    qrmanager->ncols = workingset->nVar;
    if (workingset->nWConstr[0] < workingset->nVar) {
      qrmanager->minRowCol = workingset->nWConstr[0];
    } else {
      qrmanager->minRowCol = workingset->nVar;
    }

    memcpy(&c[0], &qrmanager->QR[0], 81U * sizeof(real_T));
    QP_solver_xgeqp3(c, workingset->nWConstr[0], workingset->nVar,
                     qrmanager->jpvt, qrmanager->tau);
    memcpy(&qrmanager->QR[0], &c[0], 81U * sizeof(real_T));
    tol = 100.0 * (real_T)workingset->nVar * 2.2204460492503131E-16;
    if (workingset->nVar < workingset->nWConstr[0]) {
      i = workingset->nVar;
    } else {
      i = workingset->nWConstr[0];
    }

    while ((i > 0) && (fabs(c[((i - 1) * 9 + i) - 1]) < tol)) {
      i--;
      (*nDepInd)++;
    }

    if (*nDepInd > 0) {
      QP_solver_computeQ_(qrmanager, workingset->nWConstr[0]);
      i = 0;
      exitg1 = false;
      while ((!exitg1) && (i <= *nDepInd - 1)) {
        qtb = 0.0;
        ix = (mWorkingFixed - i) * 9;
        iy = 0;
        for (k = 0; k <= mWorkingFixed; k++) {
          qtb += qrmanager->Q[ix] * workingset->bwset[iy];
          ix++;
          iy++;
        }

        if (fabs(qtb) >= tol) {
          *nDepInd = -1;
          exitg1 = true;
        } else {
          i++;
        }
      }
    }

    if (*nDepInd > 0) {
      for (i = 0; i < 9; i++) {
        e[i] = memspace->workspace_int[i];
      }

      QP_solver_IndexOfDependentEq_(e, workingset->nWConstr[0], *nDepInd,
        qrmanager, workingset->ATwset, workingset->nVar, workingset->nWConstr[0]);
      for (i = 0; i < 9; i++) {
        b[i] = memspace->workspace_sort[i];
      }

      QP_solver_countsort(e, *nDepInd, b, 1, workingset->nWConstr[0]);
      for (i = 0; i < 9; i++) {
        memspace->workspace_int[i] = e[i];
        memspace->workspace_sort[i] = b[i];
      }

      for (mWorkingFixed = *nDepInd; mWorkingFixed > 0; mWorkingFixed--) {
        QP_solver_removeEqConstr(workingset, e[mWorkingFixed - 1]);
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_removeAllIneqConstr(sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *obj)
{
  int32_T idx_global;
  for (idx_global = obj->nWConstr[0] + obj->nWConstr[1]; idx_global <
       obj->nActiveConstr; idx_global++) {
    obj->isActiveConstr[(obj->isActiveIdx[obj->Wid[idx_global] - 1] +
                         obj->Wlocalidx[idx_global]) - 2] = false;
  }

  obj->nWConstr[2] = 0;
  obj->nWConstr[3] = 0;
  obj->nWConstr[4] = 0;
  obj->nActiveConstr = obj->nWConstr[0] + obj->nWConstr[1];
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_RemoveDependentIneq_(sH6iCrytcpDRkZmGBtfsOaB_QP_so_T
  *workingset, s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager,
  s44Ocoq5jREA8hvE3ik8GDG_QP_so_T *memspace, real_T tolfactor)
{
  real_T tol;
  int32_T b[9];
  int32_T c[9];
  int32_T i;
  int32_T nDepIneq;
  int32_T nFixedConstr;
  nFixedConstr = workingset->nWConstr[1] + workingset->nWConstr[0];
  if ((workingset->nWConstr[2] + workingset->nWConstr[3]) + workingset->
      nWConstr[4] > 0) {
    tol = tolfactor * (real_T)workingset->nVar * 2.2204460492503131E-16;
    for (nDepIneq = 0; nDepIneq < nFixedConstr; nDepIneq++) {
      qrmanager->jpvt[nDepIneq] = 1;
    }

    for (nDepIneq = nFixedConstr + 1; nDepIneq <= workingset->nActiveConstr;
         nDepIneq++) {
      qrmanager->jpvt[nDepIneq - 1] = 0;
    }

    QP_solver_factorQRE(qrmanager, workingset->ATwset, workingset->nVar,
                        workingset->nActiveConstr);
    nDepIneq = 0;
    for (i = workingset->nActiveConstr; i > workingset->nVar; i--) {
      nDepIneq++;
      memspace->workspace_int[nDepIneq - 1] = qrmanager->jpvt[i - 1];
    }

    if (i <= workingset->nVar) {
      while ((i > nFixedConstr) && (fabs(qrmanager->QR[((i - 1) * 9 + i) - 1]) <
              tol)) {
        nDepIneq++;
        memspace->workspace_int[nDepIneq - 1] = qrmanager->jpvt[i - 1];
        i--;
      }
    }

    for (i = 0; i < 9; i++) {
      b[i] = memspace->workspace_int[i];
      c[i] = memspace->workspace_sort[i];
    }

    QP_solver_countsort(b, nDepIneq, c, nFixedConstr + 1,
                        workingset->nActiveConstr);
    for (i = 0; i < 9; i++) {
      memspace->workspace_int[i] = b[i];
      memspace->workspace_sort[i] = c[i];
    }

    for (nFixedConstr = nDepIneq; nFixedConstr > 0; nFixedConstr--) {
      QP_solver_removeConstr(workingset, b[nFixedConstr - 1]);
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_factorQR_o(s5b283nY1IMTh9oT8JoHmsB_QP_so_T *obj, const
  real_T A[45], int32_T mrows, int32_T ncols)
{
  real_T b_A[81];
  real_T tau[9];
  int32_T b_idx;
  int32_T iA0;
  int32_T iQR0;
  int32_T k;
  boolean_T guard1 = false;
  b_idx = mrows * ncols;
  guard1 = false;
  if (b_idx > 0) {
    for (b_idx = 0; b_idx < ncols; b_idx++) {
      iA0 = 5 * b_idx;
      iQR0 = 9 * b_idx;
      for (k = 1; k - 1 < mrows; k++) {
        obj->QR[(iQR0 + k) - 1] = A[(iA0 + k) - 1];
      }
    }

    guard1 = true;
  } else if (b_idx == 0) {
    obj->mrows = mrows;
    obj->ncols = ncols;
    obj->minRowCol = 0;
  } else {
    guard1 = true;
  }

  if (guard1) {
    obj->usedPivoting = false;
    obj->mrows = mrows;
    obj->ncols = ncols;
    for (b_idx = 0; b_idx < ncols; b_idx++) {
      obj->jpvt[b_idx] = b_idx + 1;
    }

    if (mrows < ncols) {
      b_idx = mrows;
    } else {
      b_idx = ncols;
    }

    obj->minRowCol = b_idx;
    memcpy(&b_A[0], &obj->QR[0], 81U * sizeof(real_T));
    memset(&tau[0], 0, 9U * sizeof(real_T));
    if (b_idx >= 1) {
      memcpy(&b_A[0], &obj->QR[0], 81U * sizeof(real_T));
      memset(&tau[0], 0, 9U * sizeof(real_T));
      QP_solver_qrf(b_A, mrows, ncols, b_idx, tau);
    }

    memcpy(&obj->QR[0], &b_A[0], 81U * sizeof(real_T));
    memcpy(&obj->tau[0], &tau[0], 9U * sizeof(real_T));
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_factorQR(s5b283nY1IMTh9oT8JoHmsB_QP_so_T *obj, int32_T
  mrows, int32_T ncols)
{
  real_T A[81];
  real_T tau[9];
  int32_T idx;
  obj->usedPivoting = false;
  obj->mrows = mrows;
  obj->ncols = ncols;
  for (idx = 0; idx < ncols; idx++) {
    obj->jpvt[idx] = idx + 1;
  }

  if (mrows < ncols) {
    idx = mrows;
  } else {
    idx = ncols;
  }

  obj->minRowCol = idx;
  memcpy(&A[0], &obj->QR[0], 81U * sizeof(real_T));
  memset(&tau[0], 0, 9U * sizeof(real_T));
  if (idx >= 1) {
    memcpy(&A[0], &obj->QR[0], 81U * sizeof(real_T));
    memset(&tau[0], 0, 9U * sizeof(real_T));
    QP_solver_qrf(A, mrows, ncols, idx, tau);
  }

  memcpy(&obj->QR[0], &A[0], 81U * sizeof(real_T));
  memcpy(&obj->tau[0], &tau[0], 9U * sizeof(real_T));
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static real_T QP_solve_maxConstraintViolation(const
  sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *obj, const real_T x[45], int32_T ix0)
{
  real_T v;
  int32_T idx;
  v = 0.0;
  if (obj->sizes[3] > 0) {
    for (idx = 0; idx < obj->sizes[3]; idx++) {
      v = fmax(v, -x[(ix0 + obj->indexLB[idx]) - 2] - obj->lb[obj->indexLB[idx]
               - 1]);
    }
  }

  if (obj->sizes[4] > 0) {
    for (idx = 0; idx < obj->sizes[4]; idx++) {
      v = fmax(v, x[(ix0 + obj->indexUB[idx]) - 2] - obj->ub[obj->indexUB[idx] -
               1]);
    }
  }

  if (obj->sizes[0] > 0) {
    for (idx = 0; idx < obj->sizes[0]; idx++) {
      v = fmax(v, fabs(x[(ix0 + obj->indexFixed[idx]) - 2] - obj->ub
                       [obj->indexFixed[idx] - 1]));
    }
  }

  return v;
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static boolean_T QP_solv_feasibleX0ForWorkingSet(real_T workspace[45], real_T
  xCurrent[5], const sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset,
  s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager)
{
  real_T B[45];
  real_T c;
  real_T constrViolation_basicX;
  int32_T ar;
  int32_T b;
  int32_T b_ia;
  int32_T exitg1;
  int32_T ix;
  int32_T iy;
  int32_T jBcol;
  int32_T mWConstr;
  int32_T nVar;
  boolean_T nonDegenerateWset;
  mWConstr = workingset->nActiveConstr - 1;
  nVar = workingset->nVar;
  nonDegenerateWset = true;
  if (workingset->nActiveConstr != 0) {
    for (jBcol = 0; jBcol <= mWConstr; jBcol++) {
      workspace[jBcol] = workingset->bwset[jBcol];
      workspace[jBcol + 9] = workingset->bwset[jBcol];
    }

    if (workingset->nActiveConstr != 0) {
      iy = 0;
      jBcol = (workingset->nActiveConstr - 1) * 5;
      for (ar = 1; ar <= jBcol + 1; ar += 5) {
        ix = 0;
        c = 0.0;
        b = (ar + nVar) - 1;
        for (b_ia = ar; b_ia <= b; b_ia++) {
          c += workingset->ATwset[b_ia - 1] * xCurrent[ix];
          ix++;
        }

        workspace[iy] += -c;
        iy++;
      }
    }

    if (workingset->nActiveConstr >= workingset->nVar) {
      for (iy = 0; iy < nVar; iy++) {
        for (ar = 0; ar <= mWConstr; ar++) {
          qrmanager->QR[ar + 9 * iy] = workingset->ATwset[5 * ar + iy];
        }
      }

      QP_solver_factorQR(qrmanager, workingset->nActiveConstr, workingset->nVar);
      QP_solver_computeQ_(qrmanager, qrmanager->mrows);
      memcpy(&B[0], &workspace[0], 45U * sizeof(real_T));
      for (ar = 0; ar < nVar; ar++) {
        workspace[ar] = 0.0;
      }

      for (ar = 9; ar < nVar + 9; ar++) {
        workspace[ar] = 0.0;
      }

      ar = -1;
      for (b = 0; b < nVar; b++) {
        c = 0.0;
        for (b_ia = 1; b_ia - 1 <= mWConstr; b_ia++) {
          c += qrmanager->Q[b_ia + ar] * B[b_ia + -1];
        }

        workspace[b] += c;
        ar += 9;
      }

      ar = -1;
      for (b = 9; b < nVar + 9; b++) {
        c = 0.0;
        for (b_ia = 1; b_ia - 1 <= mWConstr; b_ia++) {
          c += qrmanager->Q[b_ia + ar] * B[b_ia + 8];
        }

        workspace[b] += c;
        ar += 9;
      }

      for (jBcol = workingset->nVar; jBcol > 0; jBcol--) {
        ar = (jBcol - 1) * 9 - 1;
        if (workspace[jBcol + -1] != 0.0) {
          workspace[jBcol + -1] /= qrmanager->QR[jBcol + ar];
          for (ix = 1; ix - 1 <= jBcol - 2; ix++) {
            workspace[ix + -1] -= workspace[jBcol + -1] * qrmanager->QR[ix + ar];
          }
        }
      }

      for (jBcol = workingset->nVar; jBcol > 0; jBcol--) {
        ar = (jBcol - 1) * 9 - 1;
        if (workspace[jBcol + 8] != 0.0) {
          workspace[jBcol + 8] /= qrmanager->QR[jBcol + ar];
          for (ix = 1; ix - 1 <= jBcol - 2; ix++) {
            workspace[ix + 8] -= workspace[jBcol + 8] * qrmanager->QR[ix + ar];
          }
        }
      }
    } else {
      QP_solver_factorQR_o(qrmanager, workingset->ATwset, workingset->nVar,
                           workingset->nActiveConstr);
      QP_solver_computeQ_(qrmanager, qrmanager->minRowCol);
      for (ar = 1; ar - 1 <= mWConstr; ar++) {
        ix = (ar - 1) * 9 - 1;
        c = workspace[ar + -1];
        for (b = 1; b - 1 <= ar - 2; b++) {
          c -= qrmanager->QR[b + ix] * workspace[b + -1];
        }

        workspace[ar + -1] = c / qrmanager->QR[ar + ix];
      }

      for (ar = 1; ar - 1 <= mWConstr; ar++) {
        ix = (ar - 1) * 9 - 1;
        c = workspace[ar + 8];
        for (b = 1; b - 1 <= ar - 2; b++) {
          c -= qrmanager->QR[b + ix] * workspace[b + 8];
        }

        workspace[ar + 8] = c / qrmanager->QR[ar + ix];
      }

      memcpy(&B[0], &workspace[0], 45U * sizeof(real_T));
      for (ar = 0; ar < nVar; ar++) {
        workspace[ar] = 0.0;
      }

      for (ar = 9; ar < nVar + 9; ar++) {
        workspace[ar] = 0.0;
      }

      ar = -1;
      for (b = 1; b <= mWConstr + 1; b++) {
        b_ia = ar;
        for (jBcol = 0; jBcol < nVar; jBcol++) {
          b_ia++;
          workspace[jBcol] += B[b - 1] * qrmanager->Q[b_ia];
        }

        ar += 9;
      }

      ar = -1;
      for (b = 10; b <= mWConstr + 10; b++) {
        b_ia = ar;
        for (jBcol = 9; jBcol < nVar + 9; jBcol++) {
          b_ia++;
          workspace[jBcol] += B[b - 1] * qrmanager->Q[b_ia];
        }

        ar += 9;
      }
    }

    mWConstr = 0;
    do {
      exitg1 = 0;
      if (mWConstr <= nVar - 1) {
        if (rtIsInf(workspace[mWConstr]) || rtIsNaN(workspace[mWConstr])) {
          nonDegenerateWset = false;
          exitg1 = 1;
        } else {
          c = workspace[mWConstr + 9];
          if (rtIsInf(c) || rtIsNaN(c)) {
            nonDegenerateWset = false;
            exitg1 = 1;
          } else {
            mWConstr++;
          }
        }
      } else {
        for (mWConstr = 0; mWConstr < nVar; mWConstr++) {
          workspace[mWConstr] += xCurrent[mWConstr];
        }

        c = QP_solve_maxConstraintViolation(workingset, workspace, 1);
        constrViolation_basicX = QP_solve_maxConstraintViolation(workingset,
          workspace, 10);
        if ((c <= 2.2204460492503131E-16) || (c < constrViolation_basicX)) {
          for (mWConstr = 0; mWConstr < nVar; mWConstr++) {
            xCurrent[mWConstr] = workspace[mWConstr];
          }
        } else {
          for (mWConstr = 0; mWConstr < nVar; mWConstr++) {
            xCurrent[mWConstr] = workspace[mWConstr + 9];
          }
        }

        exitg1 = 1;
      }
    } while (exitg1 == 0);
  }

  return nonDegenerateWset;
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static real_T QP_sol_maxConstraintViolation_i(const
  sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *obj, const real_T x[5])
{
  real_T v;
  int32_T idx;
  v = 0.0;
  if (obj->sizes[3] > 0) {
    for (idx = 0; idx < obj->sizes[3]; idx++) {
      v = fmax(v, -x[obj->indexLB[idx] - 1] - obj->lb[obj->indexLB[idx] - 1]);
    }
  }

  if (obj->sizes[4] > 0) {
    for (idx = 0; idx < obj->sizes[4]; idx++) {
      v = fmax(v, x[obj->indexUB[idx] - 1] - obj->ub[obj->indexUB[idx] - 1]);
    }
  }

  if (obj->sizes[0] > 0) {
    for (idx = 0; idx < obj->sizes[0]; idx++) {
      v = fmax(v, fabs(x[obj->indexFixed[idx] - 1] - obj->ub[obj->indexFixed[idx]
                       - 1]));
    }
  }

  return v;
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_PresolveWorkingSet(sMBHLn8PGyUK14vNDw4vTyG_QP_so_T
  *solution, s44Ocoq5jREA8hvE3ik8GDG_QP_so_T *memspace,
  sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset, s5b283nY1IMTh9oT8JoHmsB_QP_so_T
  *qrmanager, s4lHOiXA0GHbse0IgoBY6ZF_QP_so_T *options)
{
  static s4lHOiXA0GHbse0IgoBY6ZF_QP_so_T tmp = { 0.01,/* InitDamping */
    { 'f', 'o', 'r', 'w', 'a', 'r', 'd' },/* FiniteDifferenceType */
    false,                             /* SpecifyObjectiveGradient */
    false,                             /* ScaleProblem */
    false,                             /* SpecifyConstraintGradient */
    true,                              /* NonFiniteSupport */
    false,                             /* IterDisplaySQP */
    -1.0,                              /* FiniteDifferenceStepSize */
    -1.0,                              /* MaxFunctionEvaluations */
    false,                             /* IterDisplayQP */
    0.0,                               /* PricingTolerance */
    { 'a', 'c', 't', 'i', 'v', 'e', '-', 's', 'e', 't' },/* Algorithm */
    -1.0E+20,                          /* ObjectiveLimit */
    1.0E-8,                            /* ConstraintTolerance */
    1.0E-8,                            /* OptimalityTolerance */
    1.0E-8,                            /* StepTolerance */
    -1.0,                              /* MaxIterations */
    0.0,                               /* FunctionTolerance */
    { 'q', 'u', 'a', 'd', 'p', 'r', 'o', 'g' },/* SolverName */
    false,                             /* CheckGradients */
    { 'o', 'f', 'f' },                 /* Diagnostics */
    0.0,                               /* DiffMaxChange */
    0.0,                               /* DiffMinChange */
    { 'f', 'i', 'n', 'a', 'l' },       /* Display */
    { 'o', 'f', 'f' },                 /* FunValCheck */
    false,                             /* UseParallel */
    { 'a', 'u', 't', 'o' },            /* LinearSolver */
    { 'c', 'g' }                       /* SubproblemAlgorithm */
  };

  real_T c[5];
  real_T constrViolation;
  int32_T i;
  boolean_T guard1 = false;
  boolean_T okWorkingSet;
  tmp.DiffMaxChange = (rtInf);
  tmp.FunctionTolerance = (rtInf);
  *options = tmp;
  solution->state = 82;
  QP_solver_RemoveDependentEq_(memspace, workingset, &i, qrmanager);
  if (i != -1) {
    QP_solver_RemoveDependentIneq_(workingset, qrmanager, memspace, 100.0);
    for (i = 0; i < 5; i++) {
      c[i] = solution->xstar[i];
    }

    okWorkingSet = QP_solv_feasibleX0ForWorkingSet(memspace->workspace_double, c,
      workingset, qrmanager);
    for (i = 0; i < 5; i++) {
      solution->xstar[i] = c[i];
    }

    guard1 = false;
    if (!okWorkingSet) {
      QP_solver_RemoveDependentIneq_(workingset, qrmanager, memspace, 1000.0);
      okWorkingSet = QP_solv_feasibleX0ForWorkingSet(memspace->workspace_double,
        c, workingset, qrmanager);
      for (i = 0; i < 5; i++) {
        solution->xstar[i] = c[i];
      }

      if (!okWorkingSet) {
        solution->state = -7;
      } else {
        guard1 = true;
      }
    } else {
      guard1 = true;
    }

    if (guard1) {
      if (workingset->nWConstr[0] + workingset->nWConstr[1] == workingset->nVar)
      {
        constrViolation = QP_sol_maxConstraintViolation_i(workingset,
          solution->xstar);
        if (constrViolation > 1.0E-8) {
          solution->state = -2;
        }
      }
    }
  } else {
    solution->state = -3;
    QP_solver_removeAllIneqConstr(workingset);
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_linearForm_(int32_T obj_nvar, real_T workspace[45], const
  real_T H[16], const real_T f[4], const real_T x[5])
{
  real_T c;
  int32_T b;
  int32_T b_c;
  int32_T ia;
  int32_T iac;
  int32_T ix;
  int32_T iy;
  for (ix = 0; ix < obj_nvar; ix++) {
    workspace[ix] = f[ix];
  }

  ix = 0;
  b_c = (obj_nvar - 1) * obj_nvar + 1;
  iac = 1;
  while (((obj_nvar > 0) && (iac <= b_c)) || ((obj_nvar < 0) && (iac >= b_c))) {
    c = 0.5 * x[ix];
    iy = 0;
    b = (iac + obj_nvar) - 1;
    for (ia = iac; ia <= b; ia++) {
      workspace[iy] += H[ia - 1] * c;
      iy++;
    }

    ix++;
    iac += obj_nvar;
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static real_T QP_solver_computeFval(const sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *obj,
  real_T workspace[45], const real_T H[16], const real_T f[4], const real_T x[5])
{
  real_T val;
  int32_T idx;
  switch (obj->objtype) {
   case 5:
    val = x[obj->nvar - 1];
    break;

   case 3:
    QP_solver_linearForm_(obj->nvar, workspace, H, f, x);
    val = 0.0;
    if (obj->nvar >= 1) {
      for (idx = 0; idx < obj->nvar; idx++) {
        val += x[idx] * workspace[idx];
      }
    }
    break;

   default:
    QP_solver_linearForm_(obj->nvar, workspace, H, f, x);
    for (idx = obj->nvar; idx + 1 < 5; idx++) {
      workspace[idx] = 0.0 * x[idx];
    }

    val = ((x[0] * workspace[0] + x[1] * workspace[1]) + x[2] * workspace[2]) +
      x[3] * workspace[3];
    break;
  }

  return val;
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_xgemv(int32_T m, int32_T n, const real_T A[16], int32_T
  lda, const real_T x[5], real_T y[4])
{
  int32_T b;
  int32_T c;
  int32_T ia;
  int32_T iac;
  int32_T ix;
  int32_T iy;
  if ((m != 0) && (n != 0)) {
    for (ix = 0; ix < m; ix++) {
      y[ix] = 0.0;
    }

    ix = 0;
    c = (n - 1) * lda + 1;
    iac = 1;
    while (((lda > 0) && (iac <= c)) || ((lda < 0) && (iac >= c))) {
      iy = 0;
      b = (iac + m) - 1;
      for (ia = iac; ia <= b; ia++) {
        y[iy] += A[ia - 1] * x[ix];
        iy++;
      }

      ix++;
      iac += lda;
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_computeGrad_StoreHx(sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *obj,
  const real_T H[16], const real_T f[4], const real_T x[5])
{
  int32_T b_k;
  int32_T idx;
  switch (obj->objtype) {
   case 5:
    for (idx = 0; idx <= obj->nvar - 2; idx++) {
      obj->grad[idx] = 0.0;
    }

    obj->grad[obj->nvar - 1] = obj->gammaScalar;
    break;

   case 3:
    QP_solver_xgemv(obj->nvar, obj->nvar, H, obj->nvar, x, obj->Hx);
    for (idx = 0; idx < obj->nvar; idx++) {
      obj->grad[idx] = obj->Hx[idx];
    }

    if (obj->hasLinear && (obj->nvar >= 1)) {
      idx = obj->nvar - 1;
      for (b_k = 0; b_k <= idx; b_k++) {
        obj->grad[b_k] += f[b_k];
      }
    }
    break;

   default:
    QP_solver_xgemv(obj->nvar, obj->nvar, H, obj->nvar, x, obj->Hx);
    for (idx = obj->nvar; idx + 1 < 5; idx++) {
      obj->Hx[idx] = 0.0 * x[idx];
    }

    obj->grad[0] = obj->Hx[0];
    obj->grad[1] = obj->Hx[1];
    obj->grad[2] = obj->Hx[2];
    obj->grad[3] = obj->Hx[3];
    if (obj->hasLinear && (obj->nvar >= 1)) {
      idx = obj->nvar - 1;
      for (b_k = 0; b_k <= idx; b_k++) {
        obj->grad[b_k] += f[b_k];
      }
    }
    break;
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static real_T QP_solver_computeFval_ReuseHx(const
  sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *obj, real_T workspace[45], const real_T f[4],
  const real_T x[5])
{
  real_T val;
  int32_T k;
  switch (obj->objtype) {
   case 5:
    val = x[obj->nvar - 1] * obj->gammaScalar;
    break;

   case 3:
    if (obj->hasLinear) {
      for (k = 0; k < obj->nvar; k++) {
        workspace[k] = 0.5 * obj->Hx[k] + f[k];
      }

      val = 0.0;
      if (obj->nvar >= 1) {
        for (k = 0; k < obj->nvar; k++) {
          val += x[k] * workspace[k];
        }
      }
    } else {
      val = 0.0;
      if (obj->nvar >= 1) {
        for (k = 0; k < obj->nvar; k++) {
          val += x[k] * obj->Hx[k];
        }
      }

      val *= 0.5;
    }
    break;

   default:
    if (obj->hasLinear) {
      for (k = 0; k < obj->nvar; k++) {
        workspace[k] = f[k];
      }

      for (k = 0; k <= 3 - obj->nvar; k++) {
        workspace[obj->nvar + k] = 0.0;
      }

      workspace[0] += 0.5 * obj->Hx[0];
      workspace[1] += 0.5 * obj->Hx[1];
      workspace[2] += 0.5 * obj->Hx[2];
      workspace[3] += 0.5 * obj->Hx[3];
      val = ((x[0] * workspace[0] + x[1] * workspace[1]) + x[2] * workspace[2])
        + x[3] * workspace[3];
    } else {
      val = (((x[0] * obj->Hx[0] + x[1] * obj->Hx[1]) + x[2] * obj->Hx[2]) + x[3]
             * obj->Hx[3]) * 0.5;
      for (k = obj->nvar; k + 1 < 5; k++) {
        val += x[k] * 0.0;
      }
    }
    break;
  }

  return val;
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_xrotg(real_T *a, real_T *b, real_T *c, real_T *s)
{
  real_T absa;
  real_T absb;
  real_T ads;
  real_T bds;
  real_T roe;
  real_T scale;
  roe = *b;
  absa = fabs(*a);
  absb = fabs(*b);
  if (absa > absb) {
    roe = *a;
  }

  scale = absa + absb;
  if (scale == 0.0) {
    *s = 0.0;
    *c = 1.0;
    *b = 0.0;
  } else {
    ads = absa / scale;
    bds = absb / scale;
    scale *= sqrt(ads * ads + bds * bds);
    if (roe < 0.0) {
      scale = -scale;
    }

    *c = *a / scale;
    *s = *b / scale;
    if (absa > absb) {
      *b = *s;
    } else if (*c != 0.0) {
      *b = 1.0 / *c;
    } else {
      *b = 1.0;
    }
  }

  *a = scale;
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_squareQ_appendCol(s5b283nY1IMTh9oT8JoHmsB_QP_so_T *obj,
  const real_T vec[45], int32_T iv0)
{
  real_T x[81];
  real_T c;
  real_T c_c;
  real_T s;
  real_T temp;
  int32_T c_iy;
  int32_T d;
  int32_T iQR0;
  int32_T ia;
  int32_T ix;
  int32_T iyend;
  if (obj->mrows < obj->ncols + 1) {
    obj->minRowCol = obj->mrows;
  } else {
    obj->minRowCol = obj->ncols + 1;
  }

  iQR0 = 9 * obj->ncols;
  if (obj->mrows != 0) {
    iyend = iQR0 + obj->mrows;
    for (c_iy = iQR0; c_iy < iyend; c_iy++) {
      obj->QR[c_iy] = 0.0;
    }

    iyend = (obj->mrows - 1) * 9;
    for (c_iy = 1; c_iy <= iyend + 1; c_iy += 9) {
      ix = iv0;
      c_c = 0.0;
      d = (c_iy + obj->mrows) - 1;
      for (ia = c_iy; ia <= d; ia++) {
        c_c += obj->Q[ia - 1] * vec[ix - 1];
        ix++;
      }

      obj->QR[iQR0] += c_c;
      iQR0++;
    }
  }

  obj->ncols++;
  obj->jpvt[obj->ncols - 1] = obj->ncols;
  for (iQR0 = obj->mrows - 2; iQR0 + 2 > obj->ncols; iQR0--) {
    iyend = (obj->ncols - 1) * 9 + iQR0;
    temp = obj->QR[iyend];
    c = obj->QR[iyend + 1];
    QP_solver_xrotg(&temp, &c, &c_c, &s);
    obj->QR[iyend] = temp;
    obj->QR[(iQR0 + 9 * (obj->ncols - 1)) + 1] = c;
    iyend = 9 * iQR0;
    memcpy(&x[0], &obj->Q[0], 81U * sizeof(real_T));
    if (obj->mrows >= 1) {
      c_iy = iyend + 9;
      for (ix = 0; ix < obj->mrows; ix++) {
        temp = c_c * x[iyend] + s * x[c_iy];
        x[c_iy] = c_c * x[c_iy] - s * x[iyend];
        x[iyend] = temp;
        c_iy++;
        iyend++;
      }
    }

    memcpy(&obj->Q[0], &x[0], 81U * sizeof(real_T));
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_deleteColMoveEnd(s5b283nY1IMTh9oT8JoHmsB_QP_so_T *obj,
  int32_T idx)
{
  real_T x[81];
  real_T b_s;
  real_T b_temp;
  real_T c_c;
  real_T e;
  int32_T QRk0;
  int32_T b_ix;
  int32_T b_temp_tmp;
  int32_T d_iy;
  int32_T e_k;
  int32_T i;
  int32_T k;
  if (obj->usedPivoting) {
    i = 1;
    while ((i <= obj->ncols) && (obj->jpvt[i - 1] != idx)) {
      i++;
    }

    idx = i;
  }

  if (idx >= obj->ncols) {
    obj->ncols--;
  } else {
    obj->jpvt[idx - 1] = obj->jpvt[obj->ncols - 1];
    for (i = 0; i < obj->minRowCol; i++) {
      obj->QR[i + 9 * (idx - 1)] = obj->QR[(obj->ncols - 1) * 9 + i];
    }

    obj->ncols--;
    if (obj->mrows < obj->ncols) {
      obj->minRowCol = obj->mrows;
    } else {
      obj->minRowCol = obj->ncols;
    }

    if (idx < obj->mrows) {
      if (obj->mrows - 1 < obj->ncols) {
        i = obj->mrows - 1;
      } else {
        i = obj->ncols;
      }

      for (k = i; k >= idx; k--) {
        b_temp_tmp = (idx - 1) * 9 + k;
        b_temp = obj->QR[b_temp_tmp - 1];
        e = obj->QR[b_temp_tmp];
        QP_solver_xrotg(&b_temp, &e, &c_c, &b_s);
        obj->QR[b_temp_tmp - 1] = b_temp;
        obj->QR[b_temp_tmp] = e;
        b_temp_tmp = 9 * (k - 1);
        obj->QR[k + b_temp_tmp] = 0.0;
        QRk0 = 9 * idx + k;
        d_iy = obj->ncols - idx;
        memcpy(&x[0], &obj->QR[0], 81U * sizeof(real_T));
        if (d_iy >= 1) {
          b_ix = QRk0 - 1;
          for (e_k = 0; e_k < d_iy; e_k++) {
            b_temp = c_c * x[b_ix] + b_s * x[QRk0];
            x[QRk0] = c_c * x[QRk0] - b_s * x[b_ix];
            x[b_ix] = b_temp;
            QRk0 += 9;
            b_ix += 9;
          }
        }

        QRk0 = b_temp_tmp;
        for (d_iy = 0; d_iy < 81; d_iy++) {
          obj->QR[d_iy] = x[d_iy];
          x[d_iy] = obj->Q[d_iy];
        }

        if (obj->mrows >= 1) {
          d_iy = b_temp_tmp + 9;
          for (b_ix = 0; b_ix < obj->mrows; b_ix++) {
            b_temp = c_c * x[QRk0] + b_s * x[d_iy];
            x[d_iy] = c_c * x[d_iy] - b_s * x[QRk0];
            x[QRk0] = b_temp;
            d_iy++;
            QRk0++;
          }
        }

        memcpy(&obj->Q[0], &x[0], 81U * sizeof(real_T));
      }

      for (k = idx; k < i; k++) {
        b_temp_tmp = 9 * k + k;
        b_temp = obj->QR[b_temp_tmp];
        e = obj->QR[b_temp_tmp + 1];
        QP_solver_xrotg(&b_temp, &e, &c_c, &b_s);
        obj->QR[b_temp_tmp] = b_temp;
        obj->QR[b_temp_tmp + 1] = e;
        QRk0 = (k + 1) * 10;
        d_iy = (obj->ncols - k) - 2;
        memcpy(&x[0], &obj->QR[0], 81U * sizeof(real_T));
        if (d_iy + 1 >= 1) {
          b_ix = QRk0 - 1;
          for (e_k = 0; e_k <= d_iy; e_k++) {
            b_temp = c_c * x[b_ix] + b_s * x[QRk0];
            x[QRk0] = c_c * x[QRk0] - b_s * x[b_ix];
            x[b_ix] = b_temp;
            QRk0 += 9;
            b_ix += 9;
          }
        }

        QRk0 = 9 * k;
        for (b_temp_tmp = 0; b_temp_tmp < 81; b_temp_tmp++) {
          obj->QR[b_temp_tmp] = x[b_temp_tmp];
          x[b_temp_tmp] = obj->Q[b_temp_tmp];
        }

        if (obj->mrows >= 1) {
          d_iy = QRk0 + 9;
          for (b_ix = 0; b_ix < obj->mrows; b_ix++) {
            b_temp = c_c * x[QRk0] + b_s * x[d_iy];
            x[d_iy] = c_c * x[d_iy] - b_s * x[QRk0];
            x[QRk0] = b_temp;
            d_iy++;
            QRk0++;
          }
        }

        memcpy(&obj->Q[0], &x[0], 81U * sizeof(real_T));
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_xgemm(int32_T m, int32_T n, int32_T k, const real_T A[16],
  int32_T lda, const real_T B[81], int32_T ib0, real_T C[45])
{
  int32_T ar;
  int32_T b_c;
  int32_T b_cr;
  int32_T b_ic;
  int32_T br;
  int32_T c;
  int32_T d;
  int32_T ia;
  int32_T ib;
  if ((m != 0) && (n != 0)) {
    b_c = (n - 1) * 9;
    for (br = 0; br <= b_c; br += 9) {
      b_cr = br + m;
      for (ar = br; ar < b_cr; ar++) {
        C[ar] = 0.0;
      }
    }

    br = ib0;
    for (b_cr = 0; b_cr <= b_c; b_cr += 9) {
      ar = -1;
      c = br + k;
      for (ib = br; ib < c; ib++) {
        ia = ar;
        d = b_cr + m;
        for (b_ic = b_cr; b_ic < d; b_ic++) {
          ia++;
          C[b_ic] += B[ib - 1] * A[ia];
        }

        ar += lda;
      }

      br += 9;
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_xgemm_e(int32_T m, int32_T n, int32_T k, const real_T A[81],
  int32_T ia0, const real_T B[45], real_T C[81])
{
  real_T temp;
  int32_T ar;
  int32_T b_c;
  int32_T b_cr;
  int32_T b_ic;
  int32_T br;
  int32_T c;
  int32_T w;
  if ((m != 0) && (n != 0)) {
    b_c = (n - 1) * 9;
    for (br = 0; br <= b_c; br += 9) {
      b_cr = br + m;
      for (ar = br; ar < b_cr; ar++) {
        C[ar] = 0.0;
      }
    }

    br = -1;
    for (b_cr = 0; b_cr <= b_c; b_cr += 9) {
      ar = ia0;
      c = b_cr + m;
      for (b_ic = b_cr; b_ic < c; b_ic++) {
        temp = 0.0;
        for (w = 1; w - 1 < k; w++) {
          temp += A[(w + ar) - 2] * B[w + br];
        }

        C[b_ic] += temp;
        ar += 9;
      }

      br += 9;
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_fullColLDL2_(sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T *obj, int32_T
  LD_offset, int32_T NColsRemain, real_T REG_PRIMAL)
{
  real_T neg_D;
  real_T temp;
  int32_T LD_diagOffset;
  int32_T b;
  int32_T ijA;
  int32_T ix;
  int32_T j;
  int32_T jA;
  int32_T jy;
  int32_T lastDiag;
  int32_T subMatrixDim;
  for (lastDiag = 0; lastDiag < NColsRemain; lastDiag++) {
    LD_diagOffset = (10 * lastDiag + LD_offset) - 1;
    if (fabs(obj->FMat[LD_diagOffset]) <= obj->regTol_) {
      obj->FMat[LD_diagOffset] += REG_PRIMAL;
    }

    neg_D = -1.0 / obj->FMat[LD_diagOffset];
    subMatrixDim = (NColsRemain - lastDiag) - 2;
    for (jA = 0; jA <= subMatrixDim; jA++) {
      obj->workspace_[jA] = obj->FMat[(LD_diagOffset + jA) + 1];
    }

    if (!(neg_D == 0.0)) {
      jA = LD_diagOffset + 10;
      jy = 0;
      for (j = 0; j <= subMatrixDim; j++) {
        if (obj->workspace_[jy] != 0.0) {
          temp = obj->workspace_[jy] * neg_D;
          ix = 0;
          b = subMatrixDim + jA;
          for (ijA = jA; ijA < b + 1; ijA++) {
            obj->FMat[ijA] += obj->workspace_[ix] * temp;
            ix++;
          }
        }

        jy++;
        jA += 9;
      }
    }

    neg_D = 1.0 / obj->FMat[LD_diagOffset];
    subMatrixDim += LD_diagOffset;
    for (LD_diagOffset++; LD_diagOffset < subMatrixDim + 2; LD_diagOffset++) {
      obj->FMat[LD_diagOffset] *= neg_D;
    }
  }

  lastDiag = ((NColsRemain - 1) * 10 + LD_offset) - 1;
  if (fabs(obj->FMat[lastDiag]) <= obj->regTol_) {
    obj->FMat[lastDiag] += REG_PRIMAL;
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_xgemv_c(int32_T m, int32_T n, const real_T A[81], int32_T
  ia0, const real_T x[45], real_T y[5])
{
  int32_T b;
  int32_T c;
  int32_T ia;
  int32_T iac;
  int32_T ix;
  int32_T iy;
  if (m != 0) {
    for (ix = 0; ix < m; ix++) {
      y[ix] = 0.0;
    }

    ix = 0;
    b = (n - 1) * 9 + ia0;
    for (iac = ia0; iac <= b; iac += 9) {
      iy = 0;
      c = (iac + m) - 1;
      for (ia = iac; ia <= c; ia++) {
        y[iy] += A[ia - 1] * x[ix];
        iy++;
      }

      ix++;
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_partialColLDL3_(sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T *obj,
  int32_T LD_offset, int32_T NColsRemain, real_T REG_PRIMAL)
{
  real_T L_diagScale;
  int32_T FMat_offset;
  int32_T LD_diagOffset;
  int32_T W_diagOffset;
  int32_T c;
  int32_T ia;
  int32_T ix;
  int32_T iy;
  int32_T k;
  int32_T offsetColK;
  int32_T offsetColK_tmp;
  int32_T subRows;
  int32_T workspace2_offset;
  for (k = 0; k < 48; k++) {
    subRows = (NColsRemain - k) - 1;
    LD_diagOffset = (10 * k + LD_offset) - 1;
    W_diagOffset = 10 * k - 1;
    for (offsetColK = 0; offsetColK <= subRows; offsetColK++) {
      obj->workspace_[(W_diagOffset + offsetColK) + 1] = obj->FMat[LD_diagOffset
        + offsetColK];
    }

    offsetColK = 9 * k - 1;
    for (ix = 0; ix < NColsRemain; ix++) {
      obj->workspace2_[ix] = obj->workspace_[(offsetColK + ix) + 1];
    }

    if ((NColsRemain != 0) && (k != 0)) {
      ix = LD_offset + k;
      FMat_offset = (k - 1) * 9;
      for (workspace2_offset = 1; workspace2_offset <= FMat_offset + 1;
           workspace2_offset += 9) {
        iy = 0;
        c = (workspace2_offset + NColsRemain) - 1;
        for (ia = workspace2_offset; ia <= c; ia++) {
          obj->workspace2_[iy] += obj->workspace_[ia - 1] * -obj->FMat[ix - 1];
          iy++;
        }

        ix += 9;
      }
    }

    for (ix = 0; ix < NColsRemain; ix++) {
      obj->workspace_[(offsetColK + ix) + 1] = obj->workspace2_[ix];
    }

    for (offsetColK = 0; offsetColK <= subRows; offsetColK++) {
      obj->FMat[LD_diagOffset + offsetColK] = obj->workspace_[(W_diagOffset +
        offsetColK) + 1];
    }

    if (fabs(obj->FMat[LD_diagOffset]) <= obj->regTol_) {
      obj->FMat[LD_diagOffset] += REG_PRIMAL;
    }

    L_diagScale = 1.0 / obj->FMat[LD_diagOffset];
    subRows = (LD_diagOffset + subRows) + 1;
    for (LD_diagOffset++; LD_diagOffset < subRows; LD_diagOffset++) {
      obj->FMat[LD_diagOffset] *= L_diagScale;
    }
  }

  for (k = 48; k <= NColsRemain - 1; k += 48) {
    offsetColK = NColsRemain - k;
    if (48 < offsetColK) {
      W_diagOffset = 48;
    } else {
      W_diagOffset = offsetColK;
    }

    offsetColK_tmp = k + W_diagOffset;
    for (ix = k; ix < offsetColK_tmp; ix++) {
      subRows = offsetColK_tmp - ix;
      LD_diagOffset = (10 * ix + LD_offset) - 1;
      workspace2_offset = LD_offset + ix;
      for (FMat_offset = 0; FMat_offset < 48; FMat_offset++) {
        obj->workspace2_[FMat_offset] = obj->FMat[(FMat_offset * 9 +
          workspace2_offset) - 1];
      }

      if (subRows != 0) {
        FMat_offset = 0;
        for (workspace2_offset = ix + 1; workspace2_offset <= ix + 424;
             workspace2_offset += 9) {
          iy = LD_diagOffset;
          c = (workspace2_offset + subRows) - 1;
          for (ia = workspace2_offset; ia <= c; ia++) {
            obj->FMat[iy] += obj->workspace_[ia - 1] * -obj->
              workspace2_[FMat_offset];
            iy++;
          }

          FMat_offset++;
        }
      }
    }

    if (offsetColK_tmp < NColsRemain) {
      subRows = offsetColK - W_diagOffset;
      offsetColK = ((LD_offset + W_diagOffset) + 10 * k) - 1;
      for (ix = 0; ix < 48; ix++) {
        FMat_offset = (LD_offset + k) + ix * 9;
        workspace2_offset = ix * 9;
        for (iy = 1; iy - 1 < W_diagOffset; iy++) {
          obj->workspace2_[(workspace2_offset + iy) - 1] = obj->FMat
            [(FMat_offset + iy) - 2];
        }
      }

      if ((subRows != 0) && (W_diagOffset != 0)) {
        W_diagOffset = (W_diagOffset - 1) * 9 + offsetColK;
        ix = 0;
        while (offsetColK <= W_diagOffset) {
          FMat_offset = offsetColK_tmp - 1;
          ix++;
          for (workspace2_offset = ix; workspace2_offset <= ix + 423;
               workspace2_offset += 9) {
            iy = FMat_offset;
            c = offsetColK + subRows;
            for (ia = offsetColK; ia < c; ia++) {
              iy++;
              obj->FMat[ia] += -obj->workspace2_[workspace2_offset - 1] *
                obj->workspace_[iy];
            }

            FMat_offset += 9;
          }

          offsetColK += 9;
        }
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static int32_T QP_solver_ixamax(int32_T n, const real_T x[81])
{
  real_T smax;
  real_T y;
  int32_T idxmax;
  int32_T ix;
  int32_T k;
  if (n < 1) {
    idxmax = 0;
  } else {
    idxmax = 1;
    if (n > 1) {
      ix = 0;
      smax = fabs(x[0]);
      for (k = 2; k <= n; k++) {
        ix += 10;
        y = fabs(x[ix]);
        if (y > smax) {
          idxmax = k;
          smax = y;
        }
      }
    }
  }

  return idxmax;
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_factor(sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T *obj, const real_T
  A[16], int32_T ndims, int32_T ldA)
{
  real_T SCALED_REG_PRIMAL;
  int32_T LD_diagOffset;
  int32_T b_k;
  int32_T exitg2;
  int32_T k;
  int32_T order;
  boolean_T exitg1;
  SCALED_REG_PRIMAL = 1.4901161193847656E-6 * (real_T)ndims;
  obj->ndims = ndims;
  for (k = 0; k < ndims; k++) {
    LD_diagOffset = ldA * k;
    order = 9 * k;
    for (b_k = 1; b_k - 1 < ndims; b_k++) {
      obj->FMat[(order + b_k) - 1] = A[(LD_diagOffset + b_k) - 1];
    }
  }

  obj->regTol_ = fmax(fabs(obj->FMat[QP_solver_ixamax(ndims, obj->FMat) * 10 - 1])
                      * 2.2204460492503131E-16, fabs(SCALED_REG_PRIMAL));
  if (ndims > 128) {
    k = 0;
    exitg1 = false;
    while ((!exitg1) && (k < ndims)) {
      LD_diagOffset = 10 * k + 1;
      order = ndims - k;
      if (k + 48 <= ndims) {
        QP_solver_partialColLDL3_(obj, LD_diagOffset, order, SCALED_REG_PRIMAL);
        k += 48;
      } else {
        QP_solver_fullColLDL2_(obj, LD_diagOffset, order, SCALED_REG_PRIMAL);
        exitg1 = true;
      }
    }
  } else {
    QP_solver_fullColLDL2_(obj, 1, ndims, SCALED_REG_PRIMAL);
  }

  if (obj->ConvexCheck) {
    k = 0;
    do {
      exitg2 = 0;
      if (k <= ndims - 1) {
        if (obj->FMat[9 * k + k] <= 0.0) {
          obj->info = -k - 1;
          exitg2 = 1;
        } else {
          k++;
        }
      } else {
        obj->ConvexCheck = false;
        exitg2 = 1;
      }
    } while (exitg2 == 0);
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_solve(const sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T *obj, real_T
  rhs[5])
{
  real_T temp;
  int32_T b;
  int32_T i;
  int32_T ix;
  int32_T j;
  int32_T jjA;
  int32_T n;
  n = obj->ndims - 1;
  if (obj->ndims != 0) {
    for (j = 0; j <= n; j++) {
      jjA = j * 9 + j;
      b = n - j;
      for (i = 1; i - 1 < b; i++) {
        ix = j + i;
        rhs[ix] -= obj->FMat[jjA + i] * rhs[j];
      }
    }
  }

  for (n = 0; n < obj->ndims; n++) {
    rhs[n] /= obj->FMat[9 * n + n];
  }

  if (obj->ndims != 0) {
    for (n = obj->ndims - 1; n + 1 > 0; n--) {
      j = n * 9;
      temp = rhs[n];
      for (jjA = obj->ndims; jjA >= n + 2; jjA--) {
        temp -= obj->FMat[(j + jjA) - 1] * rhs[jjA - 1];
      }

      rhs[n] = temp;
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_compute_deltax(const real_T H[16],
  sMBHLn8PGyUK14vNDw4vTyG_QP_so_T *solution, s44Ocoq5jREA8hvE3ik8GDG_QP_so_T
  *memspace, const s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager,
  sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T *cholmanager, const
  sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *objective)
{
  real_T x[45];
  real_T SCALED_REG_PRIMAL;
  int32_T b_ix;
  int32_T b_nullStart;
  int32_T c_mNull;
  int32_T exitg2;
  int32_T ia;
  int32_T ix;
  int32_T mNull;
  int32_T nVar;
  int32_T nullStartIdx;
  int32_T order;
  boolean_T exitg1;
  nVar = qrmanager->mrows - 1;
  mNull = qrmanager->mrows - qrmanager->ncols;
  if (mNull <= 0) {
    for (mNull = 0; mNull <= nVar; mNull++) {
      solution->searchDir[mNull] = 0.0;
    }
  } else {
    for (nullStartIdx = 0; nullStartIdx <= nVar; nullStartIdx++) {
      solution->searchDir[nullStartIdx] = -objective->grad[nullStartIdx];
    }

    if (qrmanager->ncols <= 0) {
      switch (objective->objtype) {
       case 5:
        break;

       case 3:
        QP_solver_factor(cholmanager, H, qrmanager->mrows, qrmanager->mrows);
        if (cholmanager->info != 0) {
          solution->state = -6;
        } else {
          QP_solver_solve(cholmanager, solution->searchDir);
        }
        break;

       default:
        QP_solver_factor(cholmanager, H, objective->nvar, objective->nvar);
        if (cholmanager->info != 0) {
          solution->state = -6;
        } else {
          QP_solver_solve(cholmanager, solution->searchDir);
          for (mNull = objective->nvar; mNull < qrmanager->mrows; mNull++) {
            solution->searchDir[mNull] *= (rtInf);
          }
        }
        break;
      }
    } else {
      nullStartIdx = 9 * qrmanager->ncols + 1;
      if (objective->objtype == 5) {
        for (c_mNull = 0; c_mNull < mNull; c_mNull++) {
          memspace->workspace_double[c_mNull] = -qrmanager->Q[(qrmanager->ncols
            + c_mNull) * 9 + nVar];
        }

        QP_solver_xgemv_c(qrmanager->mrows, mNull, qrmanager->Q, nullStartIdx,
                          memspace->workspace_double, solution->searchDir);
      } else {
        if (objective->objtype == 3) {
          QP_solver_xgemm(qrmanager->mrows, mNull, qrmanager->mrows, H,
                          qrmanager->mrows, qrmanager->Q, nullStartIdx,
                          memspace->workspace_double);
          QP_solver_xgemm_e(mNull, mNull, qrmanager->mrows, qrmanager->Q,
                            nullStartIdx, memspace->workspace_double,
                            cholmanager->FMat);
        } else {
          QP_solver_xgemm(objective->nvar, mNull, objective->nvar, H,
                          objective->nvar, qrmanager->Q, nullStartIdx,
                          memspace->workspace_double);
          for (order = 0; order < mNull; order++) {
            for (b_ix = objective->nvar; b_ix < qrmanager->mrows; b_ix++) {
              memspace->workspace_double[b_ix + 9 * order] = qrmanager->Q[(order
                + qrmanager->ncols) * 9 + b_ix] * 0.0;
            }
          }

          QP_solver_xgemm_e(mNull, mNull, qrmanager->mrows, qrmanager->Q,
                            nullStartIdx, memspace->workspace_double,
                            cholmanager->FMat);
        }

        SCALED_REG_PRIMAL = 1.4901161193847656E-6 * (real_T)mNull;
        cholmanager->ndims = mNull;
        cholmanager->regTol_ = fmax(fabs(cholmanager->FMat[QP_solver_ixamax
          (mNull, cholmanager->FMat) * 10 - 1]) * 2.2204460492503131E-16,
          SCALED_REG_PRIMAL);
        if (mNull > 128) {
          c_mNull = 0;
          exitg1 = false;
          while ((!exitg1) && (c_mNull < mNull)) {
            b_nullStart = 10 * c_mNull + 1;
            order = mNull - c_mNull;
            if (c_mNull + 48 <= mNull) {
              QP_solver_partialColLDL3_(cholmanager, b_nullStart, order,
                SCALED_REG_PRIMAL);
              c_mNull += 48;
            } else {
              QP_solver_fullColLDL2_(cholmanager, b_nullStart, order,
                SCALED_REG_PRIMAL);
              exitg1 = true;
            }
          }
        } else {
          QP_solver_fullColLDL2_(cholmanager, 1, mNull, SCALED_REG_PRIMAL);
        }

        if (cholmanager->ConvexCheck) {
          c_mNull = 0;
          do {
            exitg2 = 0;
            if (c_mNull <= mNull - 1) {
              if (cholmanager->FMat[9 * c_mNull + c_mNull] <= 0.0) {
                cholmanager->info = -c_mNull - 1;
                exitg2 = 1;
              } else {
                c_mNull++;
              }
            } else {
              cholmanager->ConvexCheck = false;
              exitg2 = 1;
            }
          } while (exitg2 == 0);
        }

        if (cholmanager->info != 0) {
          solution->state = -6;
        } else {
          if (qrmanager->mrows != 0) {
            for (c_mNull = 0; c_mNull < mNull; c_mNull++) {
              memspace->workspace_double[c_mNull] = 0.0;
            }

            c_mNull = 0;
            b_nullStart = (mNull - 1) * 9 + nullStartIdx;
            for (order = nullStartIdx; order <= b_nullStart; order += 9) {
              ix = 0;
              SCALED_REG_PRIMAL = 0.0;
              b_ix = order + nVar;
              for (ia = order; ia <= b_ix; ia++) {
                SCALED_REG_PRIMAL += qrmanager->Q[ia - 1] * objective->grad[ix];
                ix++;
              }

              memspace->workspace_double[c_mNull] += -SCALED_REG_PRIMAL;
              c_mNull++;
            }
          }

          nVar = cholmanager->ndims - 1;
          memcpy(&x[0], &memspace->workspace_double[0], 45U * sizeof(real_T));
          if (cholmanager->ndims != 0) {
            for (c_mNull = 0; c_mNull <= nVar; c_mNull++) {
              b_nullStart = c_mNull * 9 + c_mNull;
              order = nVar - c_mNull;
              for (ix = 1; ix - 1 < order; ix++) {
                b_ix = c_mNull + ix;
                x[b_ix] -= cholmanager->FMat[b_nullStart + ix] * x[c_mNull];
              }
            }
          }

          for (nVar = 0; nVar < cholmanager->ndims; nVar++) {
            x[nVar] /= cholmanager->FMat[9 * nVar + nVar];
          }

          if (cholmanager->ndims != 0) {
            for (nVar = cholmanager->ndims - 1; nVar + 1 > 0; nVar--) {
              c_mNull = nVar * 9;
              SCALED_REG_PRIMAL = x[nVar];
              for (b_nullStart = cholmanager->ndims; b_nullStart >= nVar + 2;
                   b_nullStart--) {
                SCALED_REG_PRIMAL -= cholmanager->FMat[(c_mNull + b_nullStart) -
                  1] * x[b_nullStart - 1];
              }

              x[nVar] = SCALED_REG_PRIMAL;
            }
          }

          memcpy(&memspace->workspace_double[0], &x[0], 45U * sizeof(real_T));
          QP_solver_xgemv_c(qrmanager->mrows, mNull, qrmanager->Q, nullStartIdx,
                            x, solution->searchDir);
        }
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static real_T QP_solver_xnrm2_c(int32_T n, const real_T x[5])
{
  real_T absxk;
  real_T scale;
  real_T t;
  real_T y;
  int32_T k;
  y = 0.0;
  if (n >= 1) {
    if (n == 1) {
      y = fabs(x[0]);
    } else {
      scale = 3.3121686421112381E-170;
      for (k = 0; k < n; k++) {
        absxk = fabs(x[k]);
        if (absxk > scale) {
          t = scale / absxk;
          y = y * t * t + 1.0;
          scale = absxk;
        } else {
          t = absxk / scale;
          y += t * t;
        }
      }

      y = scale * sqrt(y);
    }
  }

  return y;
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_feasibleratiotest(const real_T solution_xstar[5], const
  real_T solution_searchDir[5], int32_T workingset_nVar, const real_T
  workingset_lb[5], const real_T workingset_ub[5], const int32_T
  workingset_indexLB[5], const int32_T workingset_indexUB[5], const int32_T
  workingset_sizes[5], const int32_T workingset_isActiveIdx[6], const boolean_T
  workingset_isActiveConstr[9], const int32_T workingset_nWConstr[5], boolean_T
  isPhaseOne, real_T *alpha, boolean_T *newBlocking, int32_T *constrType,
  int32_T *constrIdx)
{
  real_T denomTol;
  real_T phaseOneCorrectionP;
  real_T phaseOneCorrectionX;
  real_T pk_corrected;
  real_T ratio;
  int32_T b_idx;
  *alpha = 1.0E+30;
  *newBlocking = false;
  *constrType = 0;
  *constrIdx = 0;
  denomTol = 2.2204460492503131E-13 * QP_solver_xnrm2_c(workingset_nVar,
    solution_searchDir);
  if (workingset_nWConstr[3] < workingset_sizes[3]) {
    phaseOneCorrectionX = solution_xstar[workingset_nVar - 1] * (real_T)
      isPhaseOne;
    phaseOneCorrectionP = solution_searchDir[workingset_nVar - 1] * (real_T)
      isPhaseOne;
    for (b_idx = 0; b_idx <= workingset_sizes[3] - 2; b_idx++) {
      pk_corrected = -solution_searchDir[workingset_indexLB[b_idx] - 1] -
        phaseOneCorrectionP;
      if ((pk_corrected > denomTol) && (!workingset_isActiveConstr
           [(workingset_isActiveIdx[3] + b_idx) - 1])) {
        ratio = (-solution_xstar[workingset_indexLB[b_idx] - 1] -
                 workingset_lb[workingset_indexLB[b_idx] - 1]) -
          phaseOneCorrectionX;
        ratio = fmin(fabs(ratio), 1.0E-8 - ratio) / pk_corrected;
        if (ratio < *alpha) {
          *alpha = ratio;
          *constrType = 4;
          *constrIdx = b_idx + 1;
          *newBlocking = true;
        }
      }
    }

    b_idx = workingset_indexLB[workingset_sizes[3] - 1] - 1;
    phaseOneCorrectionX = -solution_searchDir[b_idx];
    if ((phaseOneCorrectionX > denomTol) && (!workingset_isActiveConstr
         [(workingset_isActiveIdx[3] + workingset_sizes[3]) - 2])) {
      ratio = -solution_xstar[b_idx] - workingset_lb[b_idx];
      ratio = fmin(fabs(ratio), 1.0E-8 - ratio) / phaseOneCorrectionX;
      if (ratio < *alpha) {
        *alpha = ratio;
        *constrType = 4;
        *constrIdx = workingset_sizes[3];
        *newBlocking = true;
      }
    }
  }

  if (workingset_nWConstr[4] < workingset_sizes[4]) {
    phaseOneCorrectionX = solution_xstar[workingset_nVar - 1] * (real_T)
      isPhaseOne;
    phaseOneCorrectionP = solution_searchDir[workingset_nVar - 1] * (real_T)
      isPhaseOne;
    for (b_idx = 0; b_idx < workingset_sizes[4]; b_idx++) {
      pk_corrected = solution_searchDir[workingset_indexUB[b_idx] - 1] -
        phaseOneCorrectionP;
      if ((pk_corrected > denomTol) && (!workingset_isActiveConstr
           [(workingset_isActiveIdx[4] + b_idx) - 1])) {
        ratio = (solution_xstar[workingset_indexUB[b_idx] - 1] -
                 workingset_ub[workingset_indexUB[b_idx] - 1]) -
          phaseOneCorrectionX;
        ratio = fmin(fabs(ratio), 1.0E-8 - ratio) / pk_corrected;
        if (ratio < *alpha) {
          *alpha = ratio;
          *constrType = 5;
          *constrIdx = b_idx + 1;
          *newBlocking = true;
        }
      }
    }
  }

  if (!isPhaseOne) {
    *newBlocking = (((!*newBlocking) || (!(*alpha > 1.0))) && (*newBlocking));
    *alpha = fmin(*alpha, 1.0);
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_sol_checkUnboundedOrIllPosed(sMBHLn8PGyUK14vNDw4vTyG_QP_so_T
  *solution, const sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *objective)
{
  if (objective->objtype == 5) {
    if (QP_solver_xnrm2_c(objective->nvar, solution->searchDir) > 100.0 *
        (real_T)objective->nvar * 1.4901161193847656E-8) {
      solution->state = 3;
    } else {
      solution->state = 4;
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_s_addBoundToActiveSetMatrix_(sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *obj,
  int32_T TYPE, int32_T idx_local)
{
  int32_T idx;
  int32_T idx_bnd_local;
  int32_T tmp;
  obj->nWConstr[TYPE - 1]++;
  obj->isActiveConstr[(obj->isActiveIdx[TYPE - 1] + idx_local) - 2] = true;
  obj->nActiveConstr++;
  obj->Wid[obj->nActiveConstr - 1] = TYPE;
  obj->Wlocalidx[obj->nActiveConstr - 1] = idx_local;
  tmp = obj->nActiveConstr - 1;
  if (TYPE == 5) {
    idx_bnd_local = obj->indexUB[idx_local - 1];
    obj->bwset[obj->nActiveConstr - 1] = obj->ub[idx_bnd_local - 1];
  } else {
    idx_bnd_local = obj->indexLB[idx_local - 1];
    obj->bwset[obj->nActiveConstr - 1] = obj->lb[idx_bnd_local - 1];
  }

  for (idx = 0; idx <= idx_bnd_local - 2; idx++) {
    obj->ATwset[idx + 5 * tmp] = 0.0;
  }

  obj->ATwset[(idx_bnd_local + 5 * (obj->nActiveConstr - 1)) - 1] = (real_T)
    (TYPE == 5) * 2.0 - 1.0;
  while (idx_bnd_local + 1 <= obj->nVar) {
    obj->ATwset[idx_bnd_local + 5 * tmp] = 0.0;
    idx_bnd_local++;
  }

  switch (obj->probType) {
   case 3:
   case 2:
    break;

   default:
    obj->ATwset[(obj->nVar + 5 * (obj->nActiveConstr - 1)) - 1] = -1.0;
    break;
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_compute_lambda(real_T workspace[45],
  sMBHLn8PGyUK14vNDw4vTyG_QP_so_T *solution, const
  sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *objective, const
  s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager)
{
  real_T tol;
  int32_T b;
  int32_T c_idx;
  int32_T ia;
  int32_T iac;
  int32_T ix;
  int32_T jjA;
  boolean_T guard1 = false;
  boolean_T nonDegenerate;
  if (qrmanager->ncols > 0) {
    tol = 100.0 * (real_T)qrmanager->mrows * 2.2204460492503131E-16;
    nonDegenerate = ((qrmanager->mrows > 0) && (qrmanager->ncols > 0));
    if (nonDegenerate) {
      c_idx = qrmanager->ncols;
      guard1 = false;
      if (qrmanager->mrows < qrmanager->ncols) {
        while ((c_idx > qrmanager->mrows) && (fabs(qrmanager->QR[((c_idx - 1) *
                  9 + qrmanager->mrows) - 1]) >= tol)) {
          c_idx--;
        }

        nonDegenerate = (c_idx == qrmanager->mrows);
        if (!nonDegenerate) {
        } else {
          guard1 = true;
        }
      } else {
        guard1 = true;
      }

      if (guard1) {
        while ((c_idx >= 1) && (fabs(qrmanager->QR[((c_idx - 1) * 9 + c_idx) - 1])
                >= tol)) {
          c_idx--;
        }

        nonDegenerate = (c_idx == 0);
      }
    }

    if (!nonDegenerate) {
      solution->state = -7;
    } else {
      if (qrmanager->mrows != 0) {
        for (c_idx = 0; c_idx < qrmanager->ncols; c_idx++) {
          workspace[c_idx] = 0.0;
        }

        c_idx = 0;
        jjA = (qrmanager->ncols - 1) * 9;
        for (iac = 1; iac <= jjA + 1; iac += 9) {
          ix = 0;
          tol = 0.0;
          b = (iac + qrmanager->mrows) - 1;
          for (ia = iac; ia <= b; ia++) {
            tol += qrmanager->Q[ia - 1] * objective->grad[ix];
            ix++;
          }

          workspace[c_idx] += tol;
          c_idx++;
        }
      }

      for (c_idx = qrmanager->ncols - 1; c_idx + 1 > 0; c_idx--) {
        jjA = c_idx * 9 + c_idx;
        workspace[c_idx] /= qrmanager->QR[jjA];
        for (iac = 1; iac - 1 < c_idx; iac++) {
          ix = c_idx - iac;
          workspace[ix] -= qrmanager->QR[jjA - iac] * workspace[c_idx];
        }
      }

      for (c_idx = 0; c_idx < qrmanager->ncols; c_idx++) {
        solution->lambda[c_idx] = -workspace[c_idx];
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_s_checkStoppingAndUpdateFval(int32_T *activeSetChangeID, const
  real_T f[4], sMBHLn8PGyUK14vNDw4vTyG_QP_so_T *solution,
  s44Ocoq5jREA8hvE3ik8GDG_QP_so_T *memspace, const
  sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *objective, const
  sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset, s5b283nY1IMTh9oT8JoHmsB_QP_so_T
  *qrmanager, real_T options_ObjectiveLimit, int32_T
  runTimeOptions_MaxIterations, boolean_T updateFval)
{
  real_T d[5];
  real_T b;
  real_T constrViolation_new;
  int32_T i;
  int32_T nVar;
  boolean_T nonDegenerateWset;
  solution->iterations++;
  nVar = objective->nvar - 1;
  if ((solution->iterations >= runTimeOptions_MaxIterations) &&
      ((solution->state != 1) || (objective->objtype == 5))) {
    solution->state = 0;
  }

  if (solution->iterations - solution->iterations / 50 * 50 == 0) {
    b = QP_sol_maxConstraintViolation_i(workingset, solution->xstar);
    solution->maxConstr = b;
    if (b > 1.0E-8) {
      for (i = 0; i <= nVar; i++) {
        solution->searchDir[i] = solution->xstar[i];
      }

      for (i = 0; i < 5; i++) {
        d[i] = solution->searchDir[i];
      }

      nonDegenerateWset = QP_solv_feasibleX0ForWorkingSet
        (memspace->workspace_double, d, workingset, qrmanager);
      for (i = 0; i < 5; i++) {
        solution->searchDir[i] = d[i];
      }

      if ((!nonDegenerateWset) && (solution->state != 0)) {
        solution->state = -2;
      }

      *activeSetChangeID = 0;
      constrViolation_new = QP_sol_maxConstraintViolation_i(workingset, d);
      if (constrViolation_new < b) {
        for (i = 0; i <= nVar; i++) {
          solution->xstar[i] = d[i];
        }

        solution->maxConstr = constrViolation_new;
      }
    }
  }

  if (updateFval) {
    b = QP_solver_computeFval_ReuseHx(objective, memspace->workspace_double, f,
      solution->xstar);
    solution->fstar = b;
    if ((b < options_ObjectiveLimit) && ((solution->state != 0) ||
         (objective->objtype != 5))) {
      solution->state = 2;
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_iterate(const real_T H[16], const real_T f[4],
  sMBHLn8PGyUK14vNDw4vTyG_QP_so_T *solution, s44Ocoq5jREA8hvE3ik8GDG_QP_so_T
  *memspace, sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset,
  s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager, sPZu81U7pb4xx4nEpbF8lJH_QP_so_T
  *objective, real_T options_ObjectiveLimit, int32_T
  runTimeOptions_MaxIterations, real_T runTimeOptions_ProbRelTolFactor,
  sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T *cholmanager)
{
  real_T normDelta;
  int32_T activeSetChangeID;
  int32_T exitg1;
  int32_T globalActiveConstrIdx;
  int32_T idxMinLambda;
  int32_T idx_local;
  int32_T nVar;
  boolean_T guard1 = false;
  boolean_T subProblemChanged;
  boolean_T updateFval;
  memset(&cholmanager->FMat[0], 0, 81U * sizeof(real_T));
  cholmanager->ldm = 9;
  cholmanager->ndims = 0;
  cholmanager->info = 0;
  cholmanager->scaleFactor = 100.0;
  cholmanager->ConvexCheck = true;
  cholmanager->regTol_ = 0.0;
  memset(&cholmanager->workspace_[0], 0, 432U * sizeof(real_T));
  memset(&cholmanager->workspace2_[0], 0, 432U * sizeof(real_T));
  subProblemChanged = true;
  updateFval = true;
  activeSetChangeID = 0;
  nVar = workingset->nVar;
  globalActiveConstrIdx = 0;
  QP_solver_computeGrad_StoreHx(objective, H, f, solution->xstar);
  solution->fstar = QP_solver_computeFval_ReuseHx(objective,
    memspace->workspace_double, f, solution->xstar);
  solution->state = -5;
  memset(&solution->lambda[0], 0, 9U * sizeof(real_T));
  do {
    exitg1 = 0;
    if (solution->state == -5) {
      guard1 = false;
      if (subProblemChanged) {
        switch (activeSetChangeID) {
         case 1:
          QP_solver_squareQ_appendCol(qrmanager, workingset->ATwset, 5 *
            (workingset->nActiveConstr - 1) + 1);
          break;

         case -1:
          QP_solver_deleteColMoveEnd(qrmanager, globalActiveConstrIdx);
          break;

         default:
          QP_solver_factorQR_o(qrmanager, workingset->ATwset, nVar,
                               workingset->nActiveConstr);
          QP_solver_computeQ_(qrmanager, qrmanager->mrows);
          break;
        }

        QP_solver_compute_deltax(H, solution, memspace, qrmanager, cholmanager,
          objective);
        if (solution->state != -5) {
          exitg1 = 1;
        } else {
          normDelta = QP_solver_xnrm2_c(nVar, solution->searchDir);
          guard1 = true;
        }
      } else {
        for (idxMinLambda = 0; idxMinLambda < nVar; idxMinLambda++) {
          solution->searchDir[idxMinLambda] = 0.0;
        }

        normDelta = 0.0;
        guard1 = true;
      }

      if (guard1) {
        if ((!subProblemChanged) || (normDelta < 1.4901161193847657E-10) ||
            (workingset->nActiveConstr >= nVar)) {
          QP_solver_compute_lambda(memspace->workspace_double, solution,
            objective, qrmanager);
          if (solution->state != -7) {
            idxMinLambda = 0;
            normDelta = 0.0 * runTimeOptions_ProbRelTolFactor * 0.0;
            for (idx_local = workingset->nWConstr[0] + workingset->nWConstr[1];
                 idx_local < workingset->nActiveConstr; idx_local++) {
              if (solution->lambda[idx_local] < normDelta) {
                normDelta = solution->lambda[idx_local];
                idxMinLambda = idx_local + 1;
              }
            }

            if (idxMinLambda == 0) {
              solution->state = 1;
            } else {
              activeSetChangeID = -1;
              globalActiveConstrIdx = idxMinLambda;
              subProblemChanged = true;
              QP_solver_removeConstr(workingset, idxMinLambda);
              solution->lambda[idxMinLambda - 1] = 0.0;
            }
          } else {
            idxMinLambda = workingset->nActiveConstr;
            activeSetChangeID = 0;
            globalActiveConstrIdx = workingset->nActiveConstr;
            subProblemChanged = true;
            QP_solver_removeConstr(workingset, workingset->nActiveConstr);
            solution->lambda[idxMinLambda - 1] = 0.0;
          }

          updateFval = false;
        } else {
          QP_solver_feasibleratiotest(solution->xstar, solution->searchDir,
            workingset->nVar, workingset->lb, workingset->ub,
            workingset->indexLB, workingset->indexUB, workingset->sizes,
            workingset->isActiveIdx, workingset->isActiveConstr,
            workingset->nWConstr, true, &normDelta, &updateFval, &idxMinLambda,
            &idx_local);
          if (updateFval) {
            switch (idxMinLambda) {
             case 3:
              workingset->nWConstr[2]++;
              workingset->isActiveConstr[(workingset->isActiveIdx[2] + idx_local)
                - 2] = true;
              workingset->nActiveConstr++;
              workingset->Wid[workingset->nActiveConstr - 1] = 3;
              workingset->Wlocalidx[workingset->nActiveConstr - 1] = idx_local;
              break;

             case 4:
              QP_s_addBoundToActiveSetMatrix_(workingset, 4, idx_local);
              break;

             default:
              QP_s_addBoundToActiveSetMatrix_(workingset, 5, idx_local);
              break;
            }

            activeSetChangeID = 1;
          } else {
            QP_sol_checkUnboundedOrIllPosed(solution, objective);
            subProblemChanged = false;
            if (workingset->nActiveConstr == 0) {
              solution->state = 1;
            }
          }

          if (!(normDelta == 0.0)) {
            for (idxMinLambda = 0; idxMinLambda < nVar; idxMinLambda++) {
              solution->xstar[idxMinLambda] += normDelta * solution->
                searchDir[idxMinLambda];
            }
          }

          QP_solver_computeGrad_StoreHx(objective, H, f, solution->xstar);
          updateFval = true;
        }

        QP_s_checkStoppingAndUpdateFval(&activeSetChangeID, f, solution,
          memspace, objective, workingset, qrmanager, options_ObjectiveLimit,
          runTimeOptions_MaxIterations, updateFval);
      }
    } else {
      if (!updateFval) {
        solution->fstar = QP_solver_computeFval_ReuseHx(objective,
          memspace->workspace_double, f, solution->xstar);
      }

      exitg1 = 1;
    }
  } while (exitg1 == 0);
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_phaseone(const real_T H[16], const real_T f[4],
  sMBHLn8PGyUK14vNDw4vTyG_QP_so_T *solution, s44Ocoq5jREA8hvE3ik8GDG_QP_so_T
  *memspace, sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset,
  s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager, s4lHOiXA0GHbse0IgoBY6ZF_QP_so_T
  *options, const sL9bDKomAYkxZSVrG9w6En_QP_sol_T *runTimeOptions,
  sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T *cholmanager, sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *
  objective)
{
  sPZu81U7pb4xx4nEpbF8lJH_QP_so_T b_objective;
  int32_T i;
  int32_T mEqFixed;
  int32_T nVar;
  boolean_T exitg1;
  nVar = workingset->nVar;
  solution->xstar[4] = solution->maxConstr + 1.0;
  QP_solver_removeAllIneqConstr(workingset);
  QP_solver_setProblemType(workingset, 1);
  for (i = 0; i < 5; i++) {
    objective->grad[i] = 0.0;
  }

  objective->Hx[0] = 0.0;
  objective->Hx[1] = 0.0;
  objective->Hx[2] = 0.0;
  objective->Hx[3] = 0.0;
  objective->maxVar = 5;
  objective->beta = 0.0;
  objective->rho = 0.0;
  objective->prev_objtype = 3;
  objective->prev_nvar = 4;
  objective->prev_hasLinear = true;
  objective->objtype = 5;
  objective->nvar = 5;
  objective->gammaScalar = 1.0;
  objective->hasLinear = true;
  options->ObjectiveLimit = 1.0E-8;
  options->StepTolerance = 1.4901161193847657E-10;
  solution->fstar = QP_solver_computeFval(objective, memspace->workspace_double,
    H, f, solution->xstar);
  solution->state = 5;
  b_objective = *objective;
  QP_solver_iterate(H, f, solution, memspace, workingset, qrmanager,
                    &b_objective, options->ObjectiveLimit,
                    runTimeOptions->MaxIterations,
                    runTimeOptions->ProbRelTolFactor, cholmanager);
  if (workingset->isActiveConstr[(workingset->isActiveIdx[3] + workingset->
       sizes[3]) - 2]) {
    i = workingset->sizes[0];
    exitg1 = false;
    while ((!exitg1) && (i + 1 <= workingset->nActiveConstr)) {
      if ((workingset->Wid[i] == 4) && (workingset->Wlocalidx[i] ==
           workingset->sizes[3])) {
        QP_solver_removeConstr(workingset, i + 1);
        exitg1 = true;
      } else {
        i++;
      }
    }
  }

  i = workingset->nActiveConstr;
  mEqFixed = workingset->sizes[0];
  while ((i > mEqFixed) && (i > nVar)) {
    QP_solver_removeConstr(workingset, i);
    i--;
  }

  solution->maxConstr = solution->xstar[4];
  QP_solver_setProblemType(workingset, 3);
  *objective = b_objective;
  objective->objtype = b_objective.prev_objtype;
  objective->nvar = b_objective.prev_nvar;
  objective->hasLinear = b_objective.prev_hasLinear;
  options->ObjectiveLimit = -1.0E+20;
  options->StepTolerance = 1.0E-8;
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static int32_T QP_solver_RemoveDependentEq__c(s44Ocoq5jREA8hvE3ik8GDG_QP_so_T
  *memspace, sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset,
  s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager)
{
  real_T c[81];
  real_T d[9];
  real_T qtb;
  real_T tol;
  int32_T b[9];
  int32_T e[9];
  int32_T ix;
  int32_T iy;
  int32_T k;
  int32_T mTotalWorkingEq;
  int32_T nDepInd;
  int32_T nVar;
  boolean_T exitg1;
  nVar = workingset->nVar - 1;
  mTotalWorkingEq = workingset->nWConstr[1] + workingset->nWConstr[0];
  nDepInd = 0;
  if (mTotalWorkingEq > 0) {
    for (ix = 0; ix < mTotalWorkingEq; ix++) {
      for (iy = 0; iy <= nVar; iy++) {
        qrmanager->QR[ix + 9 * iy] = workingset->ATwset[5 * ix + iy];
      }
    }

    ix = mTotalWorkingEq - workingset->nVar;
    if (0 <= ix) {
      nDepInd = ix;
    }

    for (ix = 0; ix <= nVar; ix++) {
      qrmanager->jpvt[ix] = 0;
    }

    qrmanager->usedPivoting = true;
    qrmanager->mrows = mTotalWorkingEq;
    qrmanager->ncols = workingset->nVar;
    if (mTotalWorkingEq < workingset->nVar) {
      qrmanager->minRowCol = mTotalWorkingEq;
    } else {
      qrmanager->minRowCol = workingset->nVar;
    }

    memcpy(&c[0], &qrmanager->QR[0], 81U * sizeof(real_T));
    for (nVar = 0; nVar < 9; nVar++) {
      e[nVar] = qrmanager->jpvt[nVar];
    }

    QP_solver_xgeqp3(c, mTotalWorkingEq, workingset->nVar, e, d);
    memcpy(&qrmanager->QR[0], &c[0], 81U * sizeof(real_T));
    memcpy(&qrmanager->tau[0], &d[0], 9U * sizeof(real_T));
    for (nVar = 0; nVar < 9; nVar++) {
      qrmanager->jpvt[nVar] = e[nVar];
    }

    tol = 100.0 * (real_T)workingset->nVar * 2.2204460492503131E-16;
    if (workingset->nVar < mTotalWorkingEq) {
      nVar = workingset->nVar;
    } else {
      nVar = mTotalWorkingEq;
    }

    while ((nVar > 0) && (fabs(c[((nVar - 1) * 9 + nVar) - 1]) < tol)) {
      nVar--;
      nDepInd++;
    }

    if (nDepInd > 0) {
      QP_solver_computeQ_(qrmanager, qrmanager->mrows);
      nVar = 0;
      exitg1 = false;
      while ((!exitg1) && (nVar <= nDepInd - 1)) {
        qtb = 0.0;
        ix = ((mTotalWorkingEq - nVar) - 1) * 9;
        iy = 0;
        for (k = 0; k < mTotalWorkingEq; k++) {
          qtb += qrmanager->Q[ix] * workingset->bwset[iy];
          ix++;
          iy++;
        }

        if (fabs(qtb) >= tol) {
          nDepInd = -1;
          exitg1 = true;
        } else {
          nVar++;
        }
      }
    }

    if (nDepInd > 0) {
      for (nVar = 0; nVar < 9; nVar++) {
        e[nVar] = memspace->workspace_int[nVar];
      }

      QP_solver_IndexOfDependentEq_(e, workingset->nWConstr[0], nDepInd,
        qrmanager, workingset->ATwset, workingset->nVar, mTotalWorkingEq);
      for (nVar = 0; nVar < 9; nVar++) {
        b[nVar] = memspace->workspace_sort[nVar];
      }

      QP_solver_countsort(e, nDepInd, b, 1, mTotalWorkingEq);
      for (nVar = 0; nVar < 9; nVar++) {
        memspace->workspace_int[nVar] = e[nVar];
        memspace->workspace_sort[nVar] = b[nVar];
      }

      for (mTotalWorkingEq = nDepInd; mTotalWorkingEq > 0; mTotalWorkingEq--) {
        QP_solver_removeEqConstr(workingset, e[mTotalWorkingEq - 1]);
      }
    }
  }

  return nDepInd;
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_PresolveWorkingSet_i(sMBHLn8PGyUK14vNDw4vTyG_QP_so_T
  *solution, s44Ocoq5jREA8hvE3ik8GDG_QP_so_T *memspace,
  sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset, s5b283nY1IMTh9oT8JoHmsB_QP_so_T
  *qrmanager)
{
  real_T c[5];
  real_T constrViolation;
  int32_T i;
  boolean_T guard1 = false;
  boolean_T okWorkingSet;
  solution->state = 82;
  i = QP_solver_RemoveDependentEq__c(memspace, workingset, qrmanager);
  if (i != -1) {
    QP_solver_RemoveDependentIneq_(workingset, qrmanager, memspace, 100.0);
    for (i = 0; i < 5; i++) {
      c[i] = solution->xstar[i];
    }

    okWorkingSet = QP_solv_feasibleX0ForWorkingSet(memspace->workspace_double, c,
      workingset, qrmanager);
    for (i = 0; i < 5; i++) {
      solution->xstar[i] = c[i];
    }

    guard1 = false;
    if (!okWorkingSet) {
      QP_solver_RemoveDependentIneq_(workingset, qrmanager, memspace, 1000.0);
      okWorkingSet = QP_solv_feasibleX0ForWorkingSet(memspace->workspace_double,
        c, workingset, qrmanager);
      for (i = 0; i < 5; i++) {
        solution->xstar[i] = c[i];
      }

      if (!okWorkingSet) {
        solution->state = -7;
      } else {
        guard1 = true;
      }
    } else {
      guard1 = true;
    }

    if (guard1) {
      if (workingset->nWConstr[0] + workingset->nWConstr[1] == workingset->nVar)
      {
        constrViolation = QP_sol_maxConstraintViolation_i(workingset,
          solution->xstar);
        if (constrViolation > 1.0E-8) {
          solution->state = -2;
        }
      }
    }
  } else {
    solution->state = -3;
    QP_solver_removeAllIneqConstr(workingset);
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_iterate_n(const real_T H[16], const real_T f[4],
  sMBHLn8PGyUK14vNDw4vTyG_QP_so_T *solution, s44Ocoq5jREA8hvE3ik8GDG_QP_so_T
  *memspace, sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset,
  s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager, sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T
  *cholmanager, sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *objective, real_T
  options_ObjectiveLimit, real_T options_StepTolerance, int32_T
  runTimeOptions_MaxIterations, real_T runTimeOptions_ProbRelTolFactor,
  boolean_T runTimeOptions_RemainFeasible)
{
  real_T denomTol;
  real_T normDelta;
  real_T p_max;
  real_T phaseOneCorrectionP;
  real_T phaseOneCorrectionX;
  real_T pk_corrected;
  real_T ratio;
  real_T ratio_tmp;
  real_T tolDelta;
  int32_T TYPE;
  int32_T activeConstrChangedType;
  int32_T activeSetChangeID;
  int32_T b_idx;
  int32_T exitg1;
  int32_T globalActiveConstrIdx;
  int32_T localActiveConstrIdx;
  int32_T nVar;
  boolean_T guard1 = false;
  boolean_T newBlocking;
  boolean_T subProblemChanged;
  boolean_T updateFval;
  subProblemChanged = true;
  updateFval = true;
  activeSetChangeID = 0;
  TYPE = objective->objtype;
  tolDelta = 6.7434957617430445E-7;
  nVar = workingset->nVar;
  globalActiveConstrIdx = 0;
  QP_solver_computeGrad_StoreHx(objective, H, f, solution->xstar);
  solution->fstar = QP_solver_computeFval_ReuseHx(objective,
    memspace->workspace_double, f, solution->xstar);
  if (solution->iterations < runTimeOptions_MaxIterations) {
    solution->state = -5;
  } else {
    solution->state = 0;
  }

  memset(&solution->lambda[0], 0, 9U * sizeof(real_T));
  do {
    exitg1 = 0;
    if (solution->state == -5) {
      guard1 = false;
      if (subProblemChanged) {
        switch (activeSetChangeID) {
         case 1:
          QP_solver_squareQ_appendCol(qrmanager, workingset->ATwset, 5 *
            (workingset->nActiveConstr - 1) + 1);
          break;

         case -1:
          QP_solver_deleteColMoveEnd(qrmanager, globalActiveConstrIdx);
          break;

         default:
          QP_solver_factorQR_o(qrmanager, workingset->ATwset, nVar,
                               workingset->nActiveConstr);
          QP_solver_computeQ_(qrmanager, qrmanager->mrows);
          break;
        }

        QP_solver_compute_deltax(H, solution, memspace, qrmanager, cholmanager,
          objective);
        if (solution->state != -5) {
          exitg1 = 1;
        } else {
          normDelta = QP_solver_xnrm2_c(nVar, solution->searchDir);
          guard1 = true;
        }
      } else {
        for (activeConstrChangedType = 0; activeConstrChangedType < nVar;
             activeConstrChangedType++) {
          solution->searchDir[activeConstrChangedType] = 0.0;
        }

        normDelta = 0.0;
        guard1 = true;
      }

      if (guard1) {
        if ((!subProblemChanged) || (normDelta < options_StepTolerance) ||
            (workingset->nActiveConstr >= nVar)) {
          QP_solver_compute_lambda(memspace->workspace_double, solution,
            objective, qrmanager);
          if (solution->state != -7) {
            activeConstrChangedType = 0;
            normDelta = 0.0 * runTimeOptions_ProbRelTolFactor * (real_T)(TYPE !=
              5);
            for (localActiveConstrIdx = workingset->nWConstr[0] +
                 workingset->nWConstr[1]; localActiveConstrIdx <
                 workingset->nActiveConstr; localActiveConstrIdx++) {
              if (solution->lambda[localActiveConstrIdx] < normDelta) {
                normDelta = solution->lambda[localActiveConstrIdx];
                activeConstrChangedType = localActiveConstrIdx + 1;
              }
            }

            if (activeConstrChangedType == 0) {
              solution->state = 1;
            } else {
              activeSetChangeID = -1;
              globalActiveConstrIdx = activeConstrChangedType;
              subProblemChanged = true;
              QP_solver_removeConstr(workingset, activeConstrChangedType);
              solution->lambda[activeConstrChangedType - 1] = 0.0;
            }
          } else {
            activeConstrChangedType = workingset->nActiveConstr;
            activeSetChangeID = 0;
            globalActiveConstrIdx = workingset->nActiveConstr;
            subProblemChanged = true;
            QP_solver_removeConstr(workingset, workingset->nActiveConstr);
            solution->lambda[activeConstrChangedType - 1] = 0.0;
          }

          updateFval = false;
        } else {
          updateFval = (TYPE == 5);
          if (updateFval || runTimeOptions_RemainFeasible) {
            QP_solver_feasibleratiotest(solution->xstar, solution->searchDir,
              workingset->nVar, workingset->lb, workingset->ub,
              workingset->indexLB, workingset->indexUB, workingset->sizes,
              workingset->isActiveIdx, workingset->isActiveConstr,
              workingset->nWConstr, updateFval, &normDelta, &newBlocking,
              &activeConstrChangedType, &localActiveConstrIdx);
          } else {
            normDelta = 1.0E+30;
            activeConstrChangedType = 0;
            localActiveConstrIdx = 0;
            p_max = 0.0;
            denomTol = 2.2204460492503131E-13 * QP_solver_xnrm2_c
              (workingset->nVar, solution->searchDir);
            if (workingset->nWConstr[3] < workingset->sizes[3]) {
              phaseOneCorrectionX = solution->xstar[workingset->nVar - 1] * 0.0;
              phaseOneCorrectionP = solution->searchDir[workingset->nVar - 1] *
                0.0;
              for (b_idx = 0; b_idx <= workingset->sizes[3] - 2; b_idx++) {
                pk_corrected = -solution->searchDir[workingset->indexLB[b_idx] -
                  1] - phaseOneCorrectionP;
                if ((pk_corrected > denomTol) && (!workingset->isActiveConstr
                     [(workingset->isActiveIdx[3] + b_idx) - 1])) {
                  ratio_tmp = -solution->xstar[workingset->indexLB[b_idx] - 1] -
                    workingset->lb[workingset->indexLB[b_idx] - 1];
                  ratio = (ratio_tmp - tolDelta) - phaseOneCorrectionX;
                  ratio = fmin(fabs(ratio), 1.0E-8 - ratio) / pk_corrected;
                  if ((ratio <= normDelta) && (fabs(pk_corrected) > p_max)) {
                    normDelta = ratio;
                    activeConstrChangedType = 4;
                    localActiveConstrIdx = b_idx + 1;
                    updateFval = true;
                  }

                  ratio = ratio_tmp - phaseOneCorrectionX;
                  ratio = fmin(fabs(ratio), 1.0E-8 - ratio) / pk_corrected;
                  if (ratio < normDelta) {
                    normDelta = ratio;
                    activeConstrChangedType = 4;
                    localActiveConstrIdx = b_idx + 1;
                    updateFval = true;
                    p_max = fabs(pk_corrected);
                  }
                }
              }

              b_idx = workingset->indexLB[workingset->sizes[3] - 1] - 1;
              phaseOneCorrectionX = solution->searchDir[b_idx];
              if ((-phaseOneCorrectionX > denomTol) &&
                  (!workingset->isActiveConstr[(workingset->isActiveIdx[3] +
                    workingset->sizes[3]) - 2])) {
                ratio_tmp = -solution->xstar[b_idx] - workingset->lb[b_idx];
                ratio = ratio_tmp - tolDelta;
                ratio = fmin(fabs(ratio), 1.0E-8 - ratio) / -phaseOneCorrectionX;
                if ((ratio <= normDelta) && (fabs(phaseOneCorrectionX) > p_max))
                {
                  normDelta = ratio;
                  activeConstrChangedType = 4;
                  localActiveConstrIdx = workingset->sizes[3];
                  updateFval = true;
                }

                ratio = fmin(fabs(ratio_tmp), 1.0E-8 - ratio_tmp) /
                  -phaseOneCorrectionX;
                if (ratio < normDelta) {
                  normDelta = ratio;
                  activeConstrChangedType = 4;
                  localActiveConstrIdx = workingset->sizes[3];
                  updateFval = true;
                  p_max = fabs(solution->searchDir[b_idx]);
                }
              }
            }

            if (workingset->nWConstr[4] < workingset->sizes[4]) {
              phaseOneCorrectionX = solution->xstar[workingset->nVar - 1] * 0.0;
              phaseOneCorrectionP = solution->searchDir[workingset->nVar - 1] *
                0.0;
              for (b_idx = 0; b_idx < workingset->sizes[4]; b_idx++) {
                pk_corrected = solution->searchDir[workingset->indexUB[b_idx] -
                  1] - phaseOneCorrectionP;
                if ((pk_corrected > denomTol) && (!workingset->isActiveConstr
                     [(workingset->isActiveIdx[4] + b_idx) - 1])) {
                  ratio_tmp = solution->xstar[workingset->indexUB[b_idx] - 1] -
                    workingset->ub[workingset->indexUB[b_idx] - 1];
                  ratio = (ratio_tmp - tolDelta) - phaseOneCorrectionX;
                  ratio = fmin(fabs(ratio), 1.0E-8 - ratio) / pk_corrected;
                  if ((ratio <= normDelta) && (fabs(pk_corrected) > p_max)) {
                    normDelta = ratio;
                    activeConstrChangedType = 5;
                    localActiveConstrIdx = b_idx + 1;
                    updateFval = true;
                  }

                  ratio = ratio_tmp - phaseOneCorrectionX;
                  ratio = fmin(fabs(ratio), 1.0E-8 - ratio) / pk_corrected;
                  if (ratio < normDelta) {
                    normDelta = ratio;
                    activeConstrChangedType = 5;
                    localActiveConstrIdx = b_idx + 1;
                    updateFval = true;
                    p_max = fabs(pk_corrected);
                  }
                }
              }
            }

            if (p_max > 0.0) {
              normDelta = fmax(normDelta, 6.608625846508183E-7 / p_max);
            }

            newBlocking = (((!updateFval) || (!(normDelta > 1.0))) && updateFval);
            normDelta = fmin(normDelta, 1.0);
            tolDelta += 6.608625846508183E-7;
          }

          if (newBlocking) {
            switch (activeConstrChangedType) {
             case 3:
              workingset->nWConstr[2]++;
              workingset->isActiveConstr[(workingset->isActiveIdx[2] +
                localActiveConstrIdx) - 2] = true;
              workingset->nActiveConstr++;
              workingset->Wid[workingset->nActiveConstr - 1] = 3;
              workingset->Wlocalidx[workingset->nActiveConstr - 1] =
                localActiveConstrIdx;
              break;

             case 4:
              QP_s_addBoundToActiveSetMatrix_(workingset, 4,
                localActiveConstrIdx);
              break;

             default:
              QP_s_addBoundToActiveSetMatrix_(workingset, 5,
                localActiveConstrIdx);
              break;
            }

            activeSetChangeID = 1;
          } else {
            QP_sol_checkUnboundedOrIllPosed(solution, objective);
            subProblemChanged = false;
            if (workingset->nActiveConstr == 0) {
              solution->state = 1;
            }
          }

          if (!(normDelta == 0.0)) {
            for (activeConstrChangedType = 0; activeConstrChangedType < nVar;
                 activeConstrChangedType++) {
              solution->xstar[activeConstrChangedType] += normDelta *
                solution->searchDir[activeConstrChangedType];
            }
          }

          QP_solver_computeGrad_StoreHx(objective, H, f, solution->xstar);
          updateFval = true;
        }

        QP_s_checkStoppingAndUpdateFval(&activeSetChangeID, f, solution,
          memspace, objective, workingset, qrmanager, options_ObjectiveLimit,
          runTimeOptions_MaxIterations, updateFval);
      }
    } else {
      if (!updateFval) {
        solution->fstar = QP_solver_computeFval_ReuseHx(objective,
          memspace->workspace_double, f, solution->xstar);
      }

      exitg1 = 1;
    }
  } while (exitg1 == 0);
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static boolean_T QP_solver_strcmp(const char_T a[8])
{
  static const char_T b[128] = { '\x00', '\x01', '\x02', '\x03', '\x04', '\x05',
    '\x06', '\x07', '\x08', '	', '\x0a', '\x0b', '\x0c', '\x0d', '\x0e', '\x0f',
    '\x10', '\x11', '\x12', '\x13', '\x14', '\x15', '\x16', '\x17', '\x18',
    '\x19', '\x1a', '\x1b', '\x1c', '\x1d', '\x1e', '\x1f', ' ', '!', '\"', '#',
    '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2',
    '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'a',
    'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p',
    'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '[', '\\', ']', '^', '_',
    '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
    'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}',
    '~', '\x7f' };

  static const char_T c[8] = { 'q', 'u', 'a', 'd', 'p', 'r', 'o', 'g' };

  int32_T exitg1;
  int32_T kstr;
  boolean_T b_bool;
  b_bool = false;
  kstr = 0;
  do {
    exitg1 = 0;
    if (kstr < 8) {
      if (b[(uint8_T)a[kstr]] != b[(int32_T)c[kstr]]) {
        exitg1 = 1;
      } else {
        kstr++;
      }
    } else {
      b_bool = true;
      exitg1 = 1;
    }
  } while (exitg1 == 0);

  return b_bool;
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_computeFirstOrderOpt(sMBHLn8PGyUK14vNDw4vTyG_QP_so_T
  *solution, const sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *objective, int32_T
  workingset_nVar, const real_T workingset_ATwset[45], int32_T
  workingset_nActiveConstr, real_T workspace[45])
{
  real_T smax;
  real_T y;
  int32_T b;
  int32_T b_ix;
  int32_T ia;
  int32_T iac;
  int32_T ix;
  int32_T iy;
  for (ix = 0; ix < workingset_nVar; ix++) {
    workspace[ix] = objective->grad[ix];
  }

  if (workingset_nActiveConstr != 0) {
    ix = 0;
    b_ix = (workingset_nActiveConstr - 1) * 5;
    for (iac = 1; iac <= b_ix + 1; iac += 5) {
      iy = 0;
      b = iac + workingset_nVar;
      for (ia = iac; ia < b; ia++) {
        workspace[iy] += workingset_ATwset[ia - 1] * solution->lambda[ix];
        iy++;
      }

      ix++;
    }
  }

  ix = 1;
  b_ix = 0;
  smax = fabs(workspace[0]);
  for (iac = 2; iac <= workingset_nVar; iac++) {
    b_ix++;
    y = fabs(workspace[b_ix]);
    if (y > smax) {
      ix = iac;
      smax = y;
    }
  }

  solution->firstorderopt = fabs(workspace[ix - 1]);
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_phaseone_k(const real_T H[16], const real_T f[4],
  sMBHLn8PGyUK14vNDw4vTyG_QP_so_T *solution, s44Ocoq5jREA8hvE3ik8GDG_QP_so_T
  *memspace, sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset,
  s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager, sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T
  *cholmanager, sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *objective,
  s4lHOiXA0GHbse0IgoBY6ZF_QP_so_T *options, const
  sL9bDKomAYkxZSVrG9w6En_QP_sol_T *runTimeOptions)
{
  sPZu81U7pb4xx4nEpbF8lJH_QP_so_T b_objective;
  int32_T PHASEONE;
  int32_T PROBTYPE_ORIG;
  int32_T mEqFixed;
  int32_T nVar;
  boolean_T exitg1;
  PROBTYPE_ORIG = workingset->probType;
  nVar = workingset->nVar;
  solution->xstar[4] = solution->maxConstr + 1.0;
  if (workingset->probType == 3) {
    PHASEONE = 1;
  } else {
    PHASEONE = 4;
  }

  QP_solver_removeAllIneqConstr(workingset);
  QP_solver_setProblemType(workingset, PHASEONE);
  objective->prev_objtype = objective->objtype;
  objective->prev_nvar = objective->nvar;
  objective->prev_hasLinear = objective->hasLinear;
  objective->objtype = 5;
  objective->nvar = 5;
  objective->gammaScalar = 1.0;
  objective->hasLinear = true;
  options->ObjectiveLimit = 1.0E-8;
  options->StepTolerance = 1.4901161193847657E-10;
  b_objective = *objective;
  solution->fstar = QP_solver_computeFval(objective, memspace->workspace_double,
    H, f, solution->xstar);
  solution->state = 5;
  QP_solver_iterate_n(H, f, solution, memspace, workingset, qrmanager,
                      cholmanager, &b_objective, options->ObjectiveLimit,
                      options->StepTolerance, runTimeOptions->MaxIterations,
                      runTimeOptions->ProbRelTolFactor,
                      runTimeOptions->RemainFeasible);
  if (workingset->isActiveConstr[(workingset->isActiveIdx[3] + workingset->
       sizes[3]) - 2]) {
    PHASEONE = workingset->sizes[0];
    exitg1 = false;
    while ((!exitg1) && (PHASEONE + 1 <= workingset->nActiveConstr)) {
      if ((workingset->Wid[PHASEONE] == 4) && (workingset->Wlocalidx[PHASEONE] ==
           workingset->sizes[3])) {
        QP_solver_removeConstr(workingset, PHASEONE + 1);
        exitg1 = true;
      } else {
        PHASEONE++;
      }
    }
  }

  PHASEONE = workingset->nActiveConstr;
  mEqFixed = workingset->sizes[0];
  while ((PHASEONE > mEqFixed) && (PHASEONE > nVar)) {
    QP_solver_removeConstr(workingset, PHASEONE);
    PHASEONE--;
  }

  solution->maxConstr = solution->xstar[4];
  QP_solver_setProblemType(workingset, PROBTYPE_ORIG);
  *objective = b_objective;
  objective->objtype = b_objective.prev_objtype;
  objective->nvar = b_objective.prev_nvar;
  objective->hasLinear = b_objective.prev_hasLinear;
  options->ObjectiveLimit = -1.0E+20;
  options->StepTolerance = 1.0E-8;
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_driver(const real_T H[16], const real_T f[4],
  sMBHLn8PGyUK14vNDw4vTyG_QP_so_T *solution, s44Ocoq5jREA8hvE3ik8GDG_QP_so_T
  *memspace, sH6iCrytcpDRkZmGBtfsOaB_QP_so_T *workingset,
  sL9bDKomAYkxZSVrG9w6En_QP_sol_T runTimeOptions,
  s5b283nY1IMTh9oT8JoHmsB_QP_so_T *qrmanager, sXPHwJUUvhPPvi7FGUnZtdG_QP_so_T
  *cholmanager, sPZu81U7pb4xx4nEpbF8lJH_QP_so_T *objective)
{
  s4lHOiXA0GHbse0IgoBY6ZF_QP_so_T options;
  sMBHLn8PGyUK14vNDw4vTyG_QP_so_T b_solution;
  real_T b;
  int32_T i;
  int32_T nVar;
  boolean_T guard1 = false;
  for (i = 0; i < 5; i++) {
    objective->grad[i] = 0.0;
  }

  objective->Hx[0] = 0.0;
  objective->Hx[1] = 0.0;
  objective->Hx[2] = 0.0;
  objective->Hx[3] = 0.0;
  objective->hasLinear = true;
  objective->nvar = 4;
  objective->maxVar = 5;
  objective->beta = 0.0;
  objective->rho = 0.0;
  objective->objtype = 3;
  objective->prev_objtype = 3;
  objective->prev_nvar = 0;
  objective->prev_hasLinear = false;
  objective->gammaScalar = 0.0;
  memset(&cholmanager->FMat[0], 0, 81U * sizeof(real_T));
  cholmanager->ldm = 9;
  cholmanager->ndims = 0;
  cholmanager->info = 0;
  cholmanager->scaleFactor = 100.0;
  cholmanager->ConvexCheck = true;
  cholmanager->regTol_ = 0.0;
  memset(&cholmanager->workspace_[0], 0, 432U * sizeof(real_T));
  memset(&cholmanager->workspace2_[0], 0, 432U * sizeof(real_T));
  solution->iterations = 0;
  runTimeOptions.RemainFeasible = true;
  nVar = workingset->nVar - 1;
  for (i = 0; i < workingset->sizes[0]; i++) {
    solution->xstar[workingset->indexFixed[i] - 1] = workingset->ub
      [workingset->indexFixed[i] - 1];
  }

  for (i = 0; i < workingset->sizes[3]; i++) {
    if (workingset->isActiveConstr[(workingset->isActiveIdx[3] + i) - 1]) {
      solution->xstar[workingset->indexLB[i] - 1] = -workingset->lb
        [workingset->indexLB[i] - 1];
    }
  }

  for (i = 0; i < workingset->sizes[4]; i++) {
    if (workingset->isActiveConstr[(workingset->isActiveIdx[4] + i) - 1]) {
      solution->xstar[workingset->indexUB[i] - 1] = workingset->ub
        [workingset->indexUB[i] - 1];
    }
  }

  QP_solver_PresolveWorkingSet(solution, memspace, workingset, qrmanager,
    &options);
  if (solution->state >= 0) {
    solution->iterations = 0;
    b = QP_sol_maxConstraintViolation_i(workingset, solution->xstar);
    solution->maxConstr = b;
    guard1 = false;
    if (b > 1.0E-8) {
      QP_solver_phaseone(H, f, solution, memspace, workingset, qrmanager,
                         &options, &runTimeOptions, cholmanager, objective);
      if (solution->state == 0) {
      } else {
        b = QP_sol_maxConstraintViolation_i(workingset, solution->xstar);
        solution->maxConstr = b;
        if (b > 1.0E-8) {
          memset(&solution->lambda[0], 0, 9U * sizeof(real_T));
          solution->fstar = QP_solver_computeFval(objective,
            memspace->workspace_double, H, f, solution->xstar);
          solution->state = -2;
        } else {
          if (b > 0.0) {
            for (i = 0; i <= nVar; i++) {
              solution->searchDir[i] = solution->xstar[i];
            }

            b_solution = *solution;
            QP_solver_PresolveWorkingSet_i(&b_solution, memspace, workingset,
              qrmanager);
            *solution = b_solution;
            b = QP_sol_maxConstraintViolation_i(workingset, b_solution.xstar);
            if (b >= b_solution.maxConstr) {
              solution->maxConstr = b;
              for (i = 0; i < 5; i++) {
                solution->xstar[i] = b_solution.xstar[i];
              }

              for (i = 0; i <= nVar; i++) {
                solution->xstar[i] = b_solution.searchDir[i];
              }
            }
          }

          guard1 = true;
        }
      }
    } else {
      guard1 = true;
    }

    if (guard1) {
      QP_solver_iterate_n(H, f, solution, memspace, workingset, qrmanager,
                          cholmanager, objective, options.ObjectiveLimit,
                          options.StepTolerance, runTimeOptions.MaxIterations,
                          runTimeOptions.ProbRelTolFactor, true);
      if (QP_solver_strcmp(options.SolverName) && (solution->state != -6)) {
        solution->maxConstr = QP_sol_maxConstraintViolation_i(workingset,
          solution->xstar);
        QP_solver_computeFirstOrderOpt(solution, objective, workingset->nVar,
          workingset->ATwset, workingset->nActiveConstr,
          memspace->workspace_double);
        runTimeOptions.RemainFeasible = false;
        while ((solution->iterations < runTimeOptions.MaxIterations) &&
               ((solution->state == -7) || ((solution->state == 1) &&
                 ((solution->maxConstr > 1.0E-8) || (solution->firstorderopt >
                   1.0E-8 * runTimeOptions.ProbRelTolFactor))))) {
          QP_solv_feasibleX0ForWorkingSet(memspace->workspace_double,
            solution->xstar, workingset, qrmanager);
          QP_solver_PresolveWorkingSet_i(solution, memspace, workingset,
            qrmanager);
          QP_solver_phaseone_k(H, f, solution, memspace, workingset, qrmanager,
                               cholmanager, objective, &options, &runTimeOptions);
          QP_solver_iterate_n(H, f, solution, memspace, workingset, qrmanager,
                              cholmanager, objective, options.ObjectiveLimit,
                              options.StepTolerance,
                              runTimeOptions.MaxIterations,
                              runTimeOptions.ProbRelTolFactor, false);
          solution->maxConstr = QP_sol_maxConstraintViolation_i(workingset,
            solution->xstar);
          QP_solver_computeFirstOrderOpt(solution, objective, workingset->nVar,
            workingset->ATwset, workingset->nActiveConstr,
            memspace->workspace_double);
        }
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static void QP_solver_quadprog(const real_T H[16], const real_T f[4], const
  real_T lb[4], const real_T ub[4], real_T x[4])
{
  s44Ocoq5jREA8hvE3ik8GDG_QP_so_T memspace;
  s5b283nY1IMTh9oT8JoHmsB_QP_so_T QRManager;
  sH6iCrytcpDRkZmGBtfsOaB_QP_so_T WorkingSet;
  sL9bDKomAYkxZSVrG9w6En_QP_sol_T expl_temp;
  sMBHLn8PGyUK14vNDw4vTyG_QP_so_T solution;
  sPZu81U7pb4xx4nEpbF8lJH_QP_so_T QPObjective;
  real_T H_infnrm;
  real_T f_infnrm;
  int32_T indexFixed[4];
  int32_T indexLB[4];
  int32_T indexUB[4];
  int32_T i;
  int32_T idx;
  int32_T k;
  int32_T mFixed;
  int32_T mUB;
  boolean_T guard1 = false;
  solution.fstar = 0.0;
  solution.firstorderopt = 0.0;
  memset(&solution.lambda[0], 0, 9U * sizeof(real_T));
  solution.state = 0;
  solution.maxConstr = 0.0;
  solution.iterations = 0;
  for (i = 0; i < 5; i++) {
    solution.searchDir[i] = 0.0;
  }

  solution.xstar[0] = 0.0;
  solution.xstar[1] = 0.0;
  solution.xstar[2] = 0.0;
  solution.xstar[3] = 0.0;
  k = 0;
  mUB = 0;
  mFixed = 0;
  guard1 = false;
  if ((!rtIsInf(lb[0])) && (!rtIsNaN(lb[0]))) {
    if (fabs(lb[0] - ub[0]) < 1.0E-8) {
      mFixed = 1;
      indexFixed[0] = 1;
    } else {
      k = 1;
      indexLB[0] = 1;
      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1) {
    if ((!rtIsInf(ub[0])) && (!rtIsNaN(ub[0]))) {
      mUB = 1;
      indexUB[0] = 1;
    }
  }

  guard1 = false;
  if ((!rtIsInf(lb[1])) && (!rtIsNaN(lb[1]))) {
    if (fabs(lb[1] - ub[1]) < 1.0E-8) {
      mFixed++;
      indexFixed[mFixed - 1] = 2;
    } else {
      k++;
      indexLB[k - 1] = 2;
      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1) {
    if ((!rtIsInf(ub[1])) && (!rtIsNaN(ub[1]))) {
      mUB++;
      indexUB[mUB - 1] = 2;
    }
  }

  guard1 = false;
  if ((!rtIsInf(lb[2])) && (!rtIsNaN(lb[2]))) {
    if (fabs(lb[2] - ub[2]) < 1.0E-8) {
      mFixed++;
      indexFixed[mFixed - 1] = 3;
    } else {
      k++;
      indexLB[k - 1] = 3;
      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1) {
    if ((!rtIsInf(ub[2])) && (!rtIsNaN(ub[2]))) {
      mUB++;
      indexUB[mUB - 1] = 3;
    }
  }

  guard1 = false;
  if ((!rtIsInf(lb[3])) && (!rtIsNaN(lb[3]))) {
    if (fabs(lb[3] - ub[3]) < 1.0E-8) {
      mFixed++;
      indexFixed[mFixed - 1] = 4;
    } else {
      k++;
      indexLB[k - 1] = 4;
      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1) {
    if ((!rtIsInf(ub[3])) && (!rtIsNaN(ub[3]))) {
      mUB++;
      indexUB[mUB - 1] = 4;
    }
  }

  QP_solver_factoryConstruct(k, lb, indexLB, mUB, ub, indexUB, mFixed,
    indexFixed, &WorkingSet);
  QP_solver_setProblemType(&WorkingSet, 3);
  for (idx = WorkingSet.isActiveIdx[2]; idx < 10; idx++) {
    WorkingSet.isActiveConstr[idx - 1] = false;
  }

  WorkingSet.nWConstr[0] = WorkingSet.sizes[0];
  WorkingSet.nWConstr[1] = 0;
  WorkingSet.nWConstr[2] = 0;
  WorkingSet.nWConstr[3] = 0;
  WorkingSet.nWConstr[4] = 0;
  WorkingSet.nActiveConstr = WorkingSet.nWConstr[0];
  for (idx = 0; idx < WorkingSet.sizes[0]; idx++) {
    WorkingSet.Wid[idx] = 1;
    WorkingSet.Wlocalidx[idx] = idx + 1;
    WorkingSet.isActiveConstr[idx] = true;
    for (i = 0; i <= WorkingSet.indexFixed[idx] - 2; i++) {
      WorkingSet.ATwset[i + 5 * idx] = 0.0;
    }

    WorkingSet.ATwset[(WorkingSet.indexFixed[idx] + 5 * idx) - 1] = 1.0;
    for (i = WorkingSet.indexFixed[idx]; i < WorkingSet.nVar; i++) {
      WorkingSet.ATwset[i + 5 * idx] = 0.0;
    }

    WorkingSet.bwset[idx] = WorkingSet.ub[WorkingSet.indexFixed[idx] - 1];
  }

  WorkingSet.SLACK0 = 0.0;
  H_infnrm = 0.0;
  f_infnrm = 0.0;
  for (idx = 0; idx < 4; idx++) {
    i = idx << 2;
    H_infnrm = fmax(H_infnrm, ((fabs(H[i + 1]) + fabs(H[i])) + fabs(H[i + 2])) +
                    fabs(H[i + 3]));
    f_infnrm = fmax(f_infnrm, fabs(f[idx]));
  }

  expl_temp.RemainFeasible = false;
  expl_temp.ProbRelTolFactor = fmax(fmax(1.0, f_infnrm), H_infnrm);
  expl_temp.ConstrRelTolFactor = 1.0;
  expl_temp.MaxIterations = (((mFixed + k) + mUB) + 4) * 10;
  QP_solver_driver(H, f, &solution, &memspace, &WorkingSet, expl_temp,
                   &QRManager, &QP_solver_B.CholRegManager, &QPObjective);
  x[0] = solution.xstar[0];
  x[1] = solution.xstar[1];
  x[2] = solution.xstar[2];
  x[3] = solution.xstar[3];
}

/* Model step function */
void QP_solver_step(void)
{
  static const real_T a_1[16] = { -0.5, 0.5, 0.5, -0.5, 0.5, 0.5, -0.5, -0.5,
    0.5, -0.5, 0.5, -0.5, 0.5, 0.5, 0.5, 0.5 };

  static const real_T b[16] = { -0.25, 0.25, 0.25, 0.25, 0.25, 0.25, -0.25, 0.25,
    0.25, -0.25, 0.25, 0.25, -0.25, -0.25, -0.25, 0.25 };

  static const real_T b_a_1[16] = { 0.5, -0.5, -0.5, 0.5, -0.5, -0.5, 0.5, 0.5,
    -0.5, 0.5, -0.5, 0.5, -0.5, -0.5, -0.5, -0.5 };

  real_T W[16];
  real_T a[16];
  real_T a_0[16];
  real_T b_a[16];
  real_T b_a_0[4];
  real_T rtb_F0[4];
  real_T rtb_x[4];
  real_T tmp[4];
  real_T tmp_0[4];
  real_T W_0;
  real_T absxk;
  real_T rtb_F0_d;
  real_T rtb_F1;
  real_T scale;
  real_T t;
  int32_T a_tmp;
  int32_T a_tmp_tmp;
  int32_T i;
  int32_T j;

  /* MATLAB Function: '<Root>/MATLAB Function' incorporates:
   *  Inport: '<Root>/Mx'
   *  Inport: '<Root>/My'
   *  Inport: '<Root>/Mz'
   *  Inport: '<Root>/T'
   *  Inport: '<Root>/Wt'
   *  Inport: '<Root>/Wx'
   *  Inport: '<Root>/Wy'
   *  Inport: '<Root>/Wz'
   *  Inport: '<Root>/lb'
   *  Inport: '<Root>/ub'
   */
  memset(&W[0], 0, sizeof(real_T) << 4U);
  W[0] = QP_solver_U.Wx;
  W[5] = QP_solver_U.Wy;
  W[10] = QP_solver_U.Wz;
  W[15] = QP_solver_U.Wt;
  if (((QP_solver_U.Wx + QP_solver_U.Wy) + QP_solver_U.Wz) + QP_solver_U.Wt ==
      0.0) {
    memset(&W[0], 0, sizeof(real_T) << 4U);
    W[0] = 1.0;
    W[5] = 1.0;
    W[10] = 1.0;
    W[15] = 1.0;
  }

  rtb_F0[0] = QP_solver_U.Mx;
  rtb_F0[1] = QP_solver_U.My;
  rtb_F0[2] = QP_solver_U.Mz;
  rtb_F0[3] = QP_solver_U.T;
  for (j = 0; j < 4; j++) {
    for (i = 0; i < 4; i++) {
      a_tmp_tmp = i << 2;
      a_tmp = j + a_tmp_tmp;
      a[a_tmp] = 0.0;
      b_a[a_tmp] = 0.0;
      W_0 = W[a_tmp_tmp];
      a[a_tmp] += a_1[j] * W_0;
      b_a[a_tmp] += b_a_1[j] * W_0;
      W_0 = W[a_tmp_tmp + 1];
      a[a_tmp] += a_1[j + 4] * W_0;
      b_a[a_tmp] += b_a_1[j + 4] * W_0;
      W_0 = W[a_tmp_tmp + 2];
      a[a_tmp] += a_1[j + 8] * W_0;
      b_a[a_tmp] += b_a_1[j + 8] * W_0;
      W_0 = W[a_tmp_tmp + 3];
      a[a_tmp] += a_1[j + 12] * W_0;
      b_a[a_tmp] += b_a_1[j + 12] * W_0;
    }

    b_a_0[j] = 0.0;
    for (i = 0; i < 4; i++) {
      a_tmp_tmp = i << 2;
      a_tmp = j + a_tmp_tmp;
      a_0[a_tmp] = 0.0;
      a_0[a_tmp] += b[a_tmp_tmp] * a[j];
      a_0[a_tmp] += b[a_tmp_tmp + 1] * a[j + 4];
      a_0[a_tmp] += b[a_tmp_tmp + 2] * a[j + 8];
      a_0[a_tmp] += b[a_tmp_tmp + 3] * a[j + 12];
      b_a_0[j] += b_a[a_tmp] * rtb_F0[i];
    }

    tmp[j] = QP_solver_U.lb;
    tmp_0[j] = QP_solver_U.ub;
  }

  QP_solver_quadprog(a_0, b_a_0, tmp, tmp_0, rtb_x);
  W_0 = 0.0;
  scale = 3.3121686421112381E-170;
  for (j = 0; j < 4; j++) {
    rtb_F0_d = rtb_F0[j];
    rtb_F1 = b[j + 12] * rtb_x[3] + (b[j + 8] * rtb_x[2] + (b[j + 4] * rtb_x[1]
      + b[j] * rtb_x[0]));
    absxk = fabs(rtb_F0_d - rtb_F1);
    if (absxk > scale) {
      t = scale / absxk;
      W_0 = W_0 * t * t + 1.0;
      scale = absxk;
    } else {
      t = absxk / scale;
      W_0 += t * t;
    }

    /* Outport: '<Root>/X' */
    QP_solver_Y.X[j] = rtb_x[j];

    /* Outport: '<Root>/F' */
    QP_solver_Y.F[j] = rtb_F1;

    /* Outport: '<Root>/F0' */
    QP_solver_Y.F0[j] = rtb_F0_d;
  }

  W_0 = scale * sqrt(W_0);

  /* Outport: '<Root>/sat_flag' incorporates:
   *  MATLAB Function: '<Root>/MATLAB Function'
   */
  QP_solver_Y.sat_flag = (W_0 > 0.001);
}

/* Model initialize function */
void QP_solver_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)QP_solver_M, 0,
                sizeof(RT_MODEL_QP_solver_T));

  /* external inputs */
  (void)memset(&QP_solver_U, 0, sizeof(ExtU_QP_solver_T));

  /* external outputs */
  (void) memset((void *)&QP_solver_Y, 0,
                sizeof(ExtY_QP_solver_T));

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  QP_solver_InitializeDataMapInfo();
}

/* Model terminate function */
void QP_solver_terminate(void)
{
  /* (no terminate code required) */
}
