/*
 * QP_solver_private.h
 *
 * Code generation for model "QP_solver".
 *
 * Model version              : 1.667
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Fri Apr 30 01:17:38 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Execution efficiency
 * Validation result: Not run
 */

#ifndef RTW_HEADER_QP_solver_private_h_
#define RTW_HEADER_QP_solver_private_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"

extern real_T rt_hypotd_snf(real_T u0, real_T u1);

#endif                                 /* RTW_HEADER_QP_solver_private_h_ */
